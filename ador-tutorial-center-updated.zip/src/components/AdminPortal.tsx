import React, { useState } from 'react';
import { 
  PaymentRecord, 
  TutorProfile, 
  TutoringJob, 
  JobApplication, 
  MonthlyReport, 
  CurrentUser, 
  SubAdminUser, 
  AdminDesignation, 
  AdminPermissions 
} from '../types';
import { 
  ShieldCheck, 
  CreditCard, 
  Award, 
  DollarSign, 
  FileText, 
  Briefcase, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Eye, 
  Plus, 
  Users, 
  Search,
  Filter,
  Check,
  AlertTriangle,
  UserCheck,
  UserX,
  Shield,
  Key,
  Lock,
  Edit2,
  Trash2,
  Sliders,
  ShieldAlert
} from 'lucide-react';

interface AdminPortalProps {
  payments: PaymentRecord[];
  tutors: TutorProfile[];
  jobs: TutoringJob[];
  applications: JobApplication[];
  reports: MonthlyReport[];
  currentUser: CurrentUser;
  subAdmins: SubAdminUser[];
  onUpdatePaymentStatus: (id: string, status: 'approved' | 'rejected') => void;
  onUpdateTutorMembership: (tutorId: string, status: 'verified' | 'unpaid') => void;
  onUpdateCommissionStatus: (applicationId: string, status: 'approved' | 'rejected') => void;
  onApproveReportForParent: (reportId: string) => void;
  onUpdateApplicationStatus: (applicationId: string, status: 'approved' | 'declined') => void;
  onOpenNewJobModal: () => void;
  onViewReceipt: (receiptUrl: string, details: any) => void;
  onUpdateSubAdmins: (subAdmins: SubAdminUser[]) => void;
  onSwitchAdminDesignation?: (designation: AdminDesignation) => void;
  showToast: (type: 'success' | 'error' | 'info', message: string, title?: string) => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  payments,
  tutors,
  jobs,
  applications,
  reports,
  currentUser,
  subAdmins,
  onUpdatePaymentStatus,
  onUpdateTutorMembership,
  onUpdateCommissionStatus,
  onApproveReportForParent,
  onUpdateApplicationStatus,
  onOpenNewJobModal,
  onViewReceipt,
  onUpdateSubAdmins,
  onSwitchAdminDesignation,
  showToast,
}) => {
  const currentDesignation = currentUser.adminDesignation || 'super_admin';
  const isSuperAdmin = currentDesignation === 'super_admin';

  // Sub-admin permission flags
  const canVerifyPayments = isSuperAdmin || currentUser.permissions?.canVerifyPayments !== false;
  const canVerifyTutors = isSuperAdmin || currentUser.permissions?.canVerifyTutors !== false;
  const canPostJobs = isSuperAdmin || currentUser.permissions?.canPostJobs !== false;
  const canApproveReports = isSuperAdmin || currentUser.permissions?.canApproveReports !== false;
  const canManageApplications = isSuperAdmin || currentUser.permissions?.canManageApplications !== false;
  const canAssignRoles = isSuperAdmin || currentUser.permissions?.canAssignRoles === true;

  // Set intuitive default tab according to role
  const defaultTab = 
    currentDesignation === 'finance_officer' ? 'payments' :
    currentDesignation === 'academic_coordinator' ? 'membership' :
    currentDesignation === 'counselor' ? 'reports' : 'payments';

  const [activeTab, setActiveTab] = useState<'payments' | 'membership' | 'commissions' | 'reports' | 'jobs' | 'roles'>(defaultTab);
  const [searchTerm, setSearchTerm] = useState('');

  // Sub-Admin Management Modal State
  const [isSubAdminModalOpen, setIsSubAdminModalOpen] = useState(false);
  const [editingSubAdminId, setEditingSubAdminId] = useState<string | null>(null);
  const [subAdminForm, setSubAdminForm] = useState<{
    name: string;
    email: string;
    phone: string;
    designation: AdminDesignation;
    roleTitle: string;
    permissions: AdminPermissions;
  }>({
    name: '',
    email: '',
    phone: '',
    designation: 'academic_coordinator',
    roleTitle: 'Academic Coordinator',
    permissions: {
      canVerifyPayments: false,
      canVerifyTutors: true,
      canPostJobs: true,
      canApproveReports: true,
      canManageApplications: true,
      canAssignRoles: false,
    }
  });

  const handleOpenAddSubAdmin = () => {
    setEditingSubAdminId(null);
    setSubAdminForm({
      name: '',
      email: '',
      phone: '',
      designation: 'academic_coordinator',
      roleTitle: 'Academic Coordinator',
      permissions: {
        canVerifyPayments: false,
        canVerifyTutors: true,
        canPostJobs: true,
        canApproveReports: true,
        canManageApplications: true,
        canAssignRoles: false,
      }
    });
    setIsSubAdminModalOpen(true);
  };

  const handleOpenEditSubAdmin = (admin: SubAdminUser) => {
    setEditingSubAdminId(admin.id);
    setSubAdminForm({
      name: admin.name,
      email: admin.email,
      phone: admin.phone || '',
      designation: admin.designation,
      roleTitle: admin.roleTitle,
      permissions: { ...admin.permissions }
    });
    setIsSubAdminModalOpen(true);
  };

  const handleSaveSubAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subAdminForm.name.trim() || !subAdminForm.email.trim()) {
      showToast('error', 'Name and Email are required.');
      return;
    }

    if (editingSubAdminId) {
      // Update existing
      const updated = subAdmins.map(s => {
        if (s.id === editingSubAdminId) {
          return {
            ...s,
            name: subAdminForm.name,
            email: subAdminForm.email,
            phone: subAdminForm.phone,
            designation: subAdminForm.designation,
            roleTitle: subAdminForm.roleTitle,
            permissions: subAdminForm.permissions,
          };
        }
        return s;
      });
      onUpdateSubAdmins(updated);
      showToast('success', `Updated permissions for ${subAdminForm.name}!`);
    } else {
      // Create new sub-admin
      const newAdmin: SubAdminUser = {
        id: `admin-${Date.now()}`,
        name: subAdminForm.name,
        email: subAdminForm.email,
        phone: subAdminForm.phone || '+251 91 000 0000',
        designation: subAdminForm.designation,
        roleTitle: subAdminForm.roleTitle,
        status: 'active',
        addedAt: new Date().toISOString().split('T')[0],
        lastActive: 'Newly Provisioned',
        permissions: subAdminForm.permissions,
      };
      onUpdateSubAdmins([...subAdmins, newAdmin]);
      showToast('success', `Sub-Admin ${newAdmin.name} provisioned with custom access rights!`);
    }
    setIsSubAdminModalOpen(false);
  };

  const handleToggleSubAdminStatus = (id: string) => {
    if (id === 'admin-super-1') {
      showToast('error', 'Cannot suspend the Super Administrator root account.');
      return;
    }
    const updated = subAdmins.map(s => {
      if (s.id === id) {
        const newStatus = s.status === 'active' ? 'suspended' as const : 'active' as const;
        return { ...s, status: newStatus };
      }
      return s;
    });
    onUpdateSubAdmins(updated);
    showToast('info', 'Sub-Admin status updated.');
  };

  const handleDeleteSubAdmin = (id: string) => {
    if (id === 'admin-super-1') {
      showToast('error', 'Cannot remove the Super Administrator root account.');
      return;
    }
    const updated = subAdmins.filter(s => s.id !== id);
    onUpdateSubAdmins(updated);
    showToast('info', 'Sub-Admin removed from active staff roster.');
  };

  // Counts for pending action items
  const pendingPayments = payments.filter(p => p.status === 'pending');
  const pendingMemberships = tutors.filter(t => t.membershipStatus === 'pending_verification');
  const pendingCommissions = applications.filter(a => a.status === 'approved' && a.commissionStatus === 'pending_verification');
  const pendingReports = reports.filter(r => r.status === 'pending_admin');
  const pendingApps = applications.filter(a => a.status === 'pending');

  const handlePaymentAction = (id: string, status: 'approved' | 'rejected') => {
    onUpdatePaymentStatus(id, status);
    showToast(status === 'approved' ? 'success' : 'error', `Parent payment marked as ${status}.`);
  };

  const handleMembershipAction = (tutorId: string, status: 'verified' | 'unpaid') => {
    onUpdateTutorMembership(tutorId, status);
    showToast(status === 'verified' ? 'success' : 'error', `Tutor 500 ETB membership marked as ${status}.`);
  };

  const handleCommissionAction = (appId: string, status: 'approved' | 'rejected') => {
    onUpdateCommissionStatus(appId, status);
    showToast(status === 'approved' ? 'success' : 'error', `Placement commission marked as ${status}. Contract updated.`);
  };

  const handleReportApprove = (reportId: string) => {
    onApproveReportForParent(reportId);
    showToast('success', 'Report verified by Admin and dispatched to Parent for sign-off!', 'Report Dispatched');
  };

  const handleAppAction = (appId: string, status: 'approved' | 'declined') => {
    onUpdateApplicationStatus(appId, status);
    if (status === 'approved') {
      showToast('success', 'Tutor accepted for job! Placement card unlocked for 60%/23% commission.', 'Tutor Accepted');
    } else {
      showToast('info', 'Application declined.');
    }
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      
      {/* Executive Banner with Role Identity and Switcher */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-slate-800">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-amber-400 text-slate-900 font-extrabold text-xs flex items-center gap-1">
                <ShieldCheck className="w-4 h-4" /> ADOR CENTRAL DESK
              </span>
              <span className="px-2 py-0.5 rounded-md text-xs font-bold bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 uppercase tracking-wider">
                {currentDesignation === 'super_admin' ? 'Root Super Administrator' :
                 currentDesignation === 'academic_coordinator' ? 'Academic Coordinator Sub-Admin' :
                 currentDesignation === 'finance_officer' ? 'Finance Sub-Admin' : 'Counselor Sub-Admin'}
              </span>
              <span className="text-xs text-slate-400 font-medium">Addis Ababa, Ethiopia</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Ador Tutorial Center — Executive Operations Hub
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Signed in as <strong className="text-white">{currentUser.name}</strong> ({currentUser.email}). Active session permissions are enforced with role-isolated dashboard scopes.
            </p>

            {/* Quick Interactive Role Simulator for Super Admin */}
            {onSwitchAdminDesignation && (
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center gap-2">
                <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                  <Sliders className="w-3.5 h-3.5 text-amber-400" /> Audit Perspective As:
                </span>
                <button
                  type="button"
                  onClick={() => onSwitchAdminDesignation('super_admin')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    currentDesignation === 'super_admin'
                      ? 'bg-amber-400 text-slate-900 shadow-xs'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Super Admin (Master)
                </button>
                <button
                  type="button"
                  onClick={() => onSwitchAdminDesignation('academic_coordinator')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    currentDesignation === 'academic_coordinator'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Academic Coordinator
                </button>
                <button
                  type="button"
                  onClick={() => onSwitchAdminDesignation('finance_officer')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    currentDesignation === 'finance_officer'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Finance Sub-Admin
                </button>
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0 self-start md:self-center">
            {isSuperAdmin && (
              <button
                onClick={handleOpenAddSubAdmin}
                className="px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-purple-600 hover:bg-purple-500 text-white transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Users className="w-4 h-4" />
                <span>+ Provision Sub-Admin</span>
              </button>
            )}

            {canPostJobs && (
              <button
                onClick={onOpenNewJobModal}
                className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-blue-600 hover:bg-blue-500 text-white transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Post Tutoring Opening</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* KPI Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Parent Payments */}
        <div 
          onClick={() => setActiveTab('payments')}
          className="cursor-pointer bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-blue-400 transition-all"
        >
          <div className="flex items-center justify-between text-blue-600 mb-2">
            <CreditCard className="w-5 h-5" />
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800">
              {pendingPayments.length} Pending
            </span>
          </div>
          <p className="text-2xl font-black text-slate-900">{payments.length}</p>
          <p className="text-xs font-semibold text-slate-500">Parent Monthly Payments</p>
        </div>

        {/* Registered Tutors */}
        <div 
          onClick={() => setActiveTab('membership')}
          className="cursor-pointer bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-amber-400 transition-all"
        >
          <div className="flex items-center justify-between text-amber-600 mb-2">
            <Award className="w-5 h-5" />
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800">
              {pendingMemberships.length} To Verify
            </span>
          </div>
          <p className="text-2xl font-black text-slate-900">{tutors.length}</p>
          <p className="text-xs font-semibold text-slate-500">500 ETB Memberships</p>
        </div>

        {/* Commissions Desk */}
        <div 
          onClick={() => setActiveTab('commissions')}
          className="cursor-pointer bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-emerald-400 transition-all"
        >
          <div className="flex items-center justify-between text-emerald-600 mb-2">
            <DollarSign className="w-5 h-5" />
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800">
              {pendingCommissions.length} Action
            </span>
          </div>
          <p className="text-2xl font-black text-slate-900">
            {applications.filter(a => a.status === 'approved').length}
          </p>
          <p className="text-xs font-semibold text-slate-500">60% / 23% Commissions</p>
        </div>

        {/* Monthly Reports */}
        <div 
          onClick={() => setActiveTab('reports')}
          className="cursor-pointer bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-indigo-400 transition-all"
        >
          <div className="flex items-center justify-between text-indigo-600 mb-2">
            <FileText className="w-5 h-5" />
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-800">
              {pendingReports.length} Review
            </span>
          </div>
          <p className="text-2xl font-black text-slate-900">{reports.length}</p>
          <p className="text-xs font-semibold text-slate-500">Student Progress Reports</p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap border-b border-slate-200 gap-2 sm:gap-4 overflow-x-auto">
        <button
          id="admin-tab-payments"
          onClick={() => setActiveTab('payments')}
          className={`pb-4 px-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
            activeTab === 'payments'
              ? 'border-blue-600 text-blue-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>Parent Monthly Payments</span>
          {pendingPayments.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[11px] bg-blue-600 text-white font-extrabold">
              {pendingPayments.length}
            </span>
          )}
        </button>

        <button
          id="admin-tab-membership"
          onClick={() => setActiveTab('membership')}
          className={`pb-4 px-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
            activeTab === 'membership'
              ? 'border-amber-600 text-amber-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Tutor 500 ETB Memberships</span>
          {pendingMemberships.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[11px] bg-amber-600 text-white font-extrabold">
              {pendingMemberships.length}
            </span>
          )}
        </button>

        <button
          id="admin-tab-commissions"
          onClick={() => setActiveTab('commissions')}
          className={`pb-4 px-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
            activeTab === 'commissions'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Job Commissions (60% / 23%)</span>
          {pendingCommissions.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[11px] bg-emerald-600 text-white font-extrabold">
              {pendingCommissions.length}
            </span>
          )}
        </button>

        <button
          id="admin-tab-reports"
          onClick={() => setActiveTab('reports')}
          className={`pb-4 px-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
            activeTab === 'reports'
              ? 'border-indigo-600 text-indigo-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Monthly Reports &amp; Parent Feedback</span>
          {pendingReports.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[11px] bg-indigo-600 text-white font-extrabold">
              {pendingReports.length}
            </span>
          )}
        </button>

        <button
          id="admin-tab-jobs"
          onClick={() => setActiveTab('jobs')}
          className={`pb-4 px-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
            activeTab === 'jobs'
              ? 'border-slate-800 text-slate-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          <span>Jobs &amp; Applications</span>
          {pendingApps.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[11px] bg-slate-700 text-white font-extrabold">
              {pendingApps.length}
            </span>
          )}
        </button>

        <button
          id="admin-tab-roles"
          onClick={() => setActiveTab('roles')}
          className={`pb-4 px-3 text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
            activeTab === 'roles'
              ? 'border-purple-600 text-purple-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Role Assigning &amp; Sub-Admins</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-purple-100 text-purple-800 font-extrabold border border-purple-200">
            {subAdmins.length} Staff
          </span>
        </button>
      </div>

      {/* TAB 1: PARENT PAYMENTS VERIFICATION DESK */}
      {activeTab === 'payments' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Parent Payment Verification Desk</h3>
              <p className="text-xs text-slate-500">
                Review bank transfer and Telebirr receipt screenshots submitted by parents by month.
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700">
              {payments.length} Total Records
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold text-xs uppercase tracking-wider">
                  <th className="pb-3 pr-2">Parent &amp; Student</th>
                  <th className="pb-3 px-2">Selected Month</th>
                  <th className="pb-3 px-2">Method &amp; Ref</th>
                  <th className="pb-3 px-2">Receipt Screenshot</th>
                  <th className="pb-3 px-2">Status</th>
                  <th className="pb-3 pl-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {payments.map((pay) => {
                  const isApproved = pay.status === 'approved';
                  const isPending = pay.status === 'pending';
                  const isRejected = pay.status === 'rejected';

                  return (
                    <tr key={pay.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 pr-2">
                        <strong className="text-slate-900 block text-xs sm:text-sm">{pay.parentName}</strong>
                        <span className="text-xs text-slate-500">Student: {pay.studentName}</span>
                      </td>
                      <td className="py-3.5 px-2">
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-800 border border-blue-100">
                          {pay.month}
                        </span>
                        <span className="block text-xs font-bold text-slate-700 mt-1">
                          {pay.amount.toLocaleString()} ETB
                        </span>
                      </td>
                      <td className="py-3.5 px-2">
                        <span className="font-medium text-slate-800 text-xs block">{pay.method}</span>
                        <code className="text-[11px] font-mono text-slate-500">{pay.reference}</code>
                      </td>
                      <td className="py-3.5 px-2">
                        <button
                          onClick={() => onViewReceipt(pay.screenshotUrl, {
                            payerOrStudent: `${pay.parentName} (${pay.studentName})`,
                            amount: pay.amount,
                            method: pay.method,
                            reference: pay.reference,
                            monthOrPurpose: pay.month,
                            status: pay.status,
                          })}
                          className="flex items-center gap-2 group p-1 rounded-lg hover:bg-slate-100 transition-colors"
                        >
                          <img
                            src={pay.screenshotUrl}
                            alt="Receipt thumb"
                            className="w-10 h-10 object-cover rounded-md border border-slate-200 group-hover:shadow-xs"
                          />
                          <span className="text-xs font-bold text-blue-700 group-hover:underline">
                            Expand 🔍
                          </span>
                        </button>
                      </td>
                      <td className="py-3.5 px-2">
                        {isApproved ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Approved
                          </span>
                        ) : isPending ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                            <Clock className="w-3.5 h-3.5" /> Pending
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                            <XCircle className="w-3.5 h-3.5" /> Rejected
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 pl-2 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => handlePaymentAction(pay.id, 'approved')}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 transition-colors"
                          >
                            ✔ Approve
                          </button>
                          <button
                            onClick={() => handlePaymentAction(pay.id, 'rejected')}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-300 transition-colors"
                          >
                            ✖ Reject
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: TUTOR 500 ETB MEMBERSHIP DESK */}
      {activeTab === 'membership' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Tutor 500 ETB Membership Fee Desk</h3>
            <p className="text-xs text-slate-500">
              Verify 500 ETB onboarding payment receipts submitted by instructors following Telegram terms confirmation.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold text-xs uppercase tracking-wider">
                  <th className="pb-3 pr-2">Tutor Name &amp; Contact</th>
                  <th className="pb-3 px-2">Method &amp; Ref</th>
                  <th className="pb-3 px-2">500 ETB Receipt</th>
                  <th className="pb-3 px-2">Status</th>
                  <th className="pb-3 pl-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {tutors.map((t) => {
                  const isVerified = t.membershipStatus === 'verified';
                  const isPending = t.membershipStatus === 'pending_verification';

                  return (
                    <tr key={t.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 pr-2">
                        <strong className="text-slate-900 block">{t.name}</strong>
                        <span className="text-xs text-slate-500">{t.email} &bull; {t.phone}</span>
                      </td>
                      <td className="py-3.5 px-2">
                        <span className="font-medium text-slate-800 text-xs block">{t.membershipMethod || '-'}</span>
                        <code className="text-[11px] font-mono text-slate-500">{t.membershipReference || '-'}</code>
                      </td>
                      <td className="py-3.5 px-2">
                        {t.membershipReceiptUrl ? (
                          <button
                            onClick={() => onViewReceipt(t.membershipReceiptUrl!, {
                              payerOrStudent: t.name,
                              amount: 500,
                              method: t.membershipMethod,
                              reference: t.membershipReference,
                              monthOrPurpose: 'Tutor 500 ETB Membership',
                              status: t.membershipStatus,
                            })}
                            className="flex items-center gap-2 group p-1 rounded-lg hover:bg-slate-100"
                          >
                            <img
                              src={t.membershipReceiptUrl}
                              alt="Receipt thumb"
                              className="w-10 h-10 object-cover rounded-md border border-slate-200"
                            />
                            <span className="text-xs font-bold text-blue-700 group-hover:underline">
                              Expand 🔍
                            </span>
                          </button>
                        ) : (
                          <span className="text-xs text-slate-400">No Receipt Yet</span>
                        )}
                      </td>
                      <td className="py-3.5 px-2">
                        {isVerified ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Verified Member
                          </span>
                        ) : isPending ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                            <Clock className="w-3.5 h-3.5" /> Under Review
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                            Unpaid
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 pl-2 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => handleMembershipAction(t.id, 'verified')}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 transition-colors"
                          >
                            ✔ Verify
                          </button>
                          <button
                            onClick={() => handleMembershipAction(t.id, 'unpaid')}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-300 transition-colors"
                          >
                            ✖ Reject
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: TUTOR JOB PLACEMENT COMMISSIONS (60% Downpayment vs 23% Monthly) */}
      {activeTab === 'commissions' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900">
              Job Placement Commission Verification Desk
            </h3>
            <p className="text-xs text-slate-500">
              Review chosen commission structures (Option 1: 60% Downpayment OR Option 2: 23% Monthly) and receipts submitted by accepted instructors.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold text-xs uppercase tracking-wider">
                  <th className="pb-3 pr-2">Job Title &amp; Tutor</th>
                  <th className="pb-3 px-2">Chosen Commission Option</th>
                  <th className="pb-3 px-2">Method &amp; Ref</th>
                  <th className="pb-3 px-2">Receipt Proof</th>
                  <th className="pb-3 px-2">Contract Status</th>
                  <th className="pb-3 pl-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {applications
                  .filter(app => app.status === 'approved')
                  .map((app) => {
                    const isApproved = app.commissionStatus === 'approved';
                    const isPending = app.commissionStatus === 'pending_verification';

                    return (
                      <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3.5 pr-2">
                          <strong className="text-slate-900 block">{app.jobTitle}</strong>
                          <span className="text-xs text-slate-500">Tutor: {app.tutorName}</span>
                        </td>
                        <td className="py-3.5 px-2">
                          {app.commissionChoice === '60_percent_first_month' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200">
                              Option 1: 60% Downpayment
                            </span>
                          ) : app.commissionChoice === '23_percent_monthly' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                              Option 2: 23% Monthly
                            </span>
                          ) : (
                            <span className="text-xs text-slate-400 italic">Pending Tutor Choice</span>
                          )}
                        </td>
                        <td className="py-3.5 px-2">
                          <span className="font-medium text-slate-800 text-xs block">{app.commissionMethod || '-'}</span>
                          <code className="text-[11px] font-mono text-slate-500">{app.commissionReference || '-'}</code>
                        </td>
                        <td className="py-3.5 px-2">
                          {app.commissionReceiptUrl ? (
                            <button
                              onClick={() => onViewReceipt(app.commissionReceiptUrl!, {
                                payerOrStudent: app.tutorName,
                                method: app.commissionMethod,
                                reference: app.commissionReference,
                                monthOrPurpose: app.commissionChoice === '60_percent_first_month' ? '60% Placement Downpayment' : '23% Monthly Commission',
                                status: app.commissionStatus,
                              })}
                              className="flex items-center gap-2 group p-1 rounded-lg hover:bg-slate-100"
                            >
                              <img
                                src={app.commissionReceiptUrl}
                                alt="Receipt thumb"
                                className="w-10 h-10 object-cover rounded-md border border-slate-200"
                              />
                              <span className="text-xs font-bold text-blue-700 group-hover:underline">
                                Expand 🔍
                              </span>
                            </button>
                          ) : (
                            <span className="text-xs text-slate-400">No Receipt Yet</span>
                          )}
                        </td>
                        <td className="py-3.5 px-2">
                          {isApproved ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Contract Active
                            </span>
                          ) : isPending ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                              <Clock className="w-3.5 h-3.5" /> Under Verification
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                              Unpaid
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 pl-2 text-right">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              onClick={() => handleCommissionAction(app.id, 'approved')}
                              className="px-2.5 py-1 rounded-lg text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 transition-colors"
                            >
                              ✔ Approve
                            </button>
                            <button
                              onClick={() => handleCommissionAction(app.id, 'rejected')}
                              className="px-2.5 py-1 rounded-lg text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-300 transition-colors"
                            >
                              ✖ Reject
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: MONTHLY REPORTS & LIVE PARENT FEEDBACK */}
      {activeTab === 'reports' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900">
              Tutor Monthly Reports &amp; Live Parent Feedback
            </h3>
            <p className="text-xs text-slate-500">
              Review evaluations submitted by tutors, approve them to dispatch to parents, and track whether parents Accepted or Disputed.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold text-xs uppercase tracking-wider">
                  <th className="pb-3 pr-2">Tutor &amp; Student</th>
                  <th className="pb-3 px-2">Month &amp; Hours</th>
                  <th className="pb-3 px-2">Evaluation Summary</th>
                  <th className="pb-3 px-2">Admin Status</th>
                  <th className="pb-3 px-2">Parent Decision</th>
                  <th className="pb-3 pl-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {reports.map((rep) => {
                  const isApprovedForParent = rep.status === 'approved_for_parent';
                  const isAccepted = rep.parentDecision === 'accepted';
                  const isDeclined = rep.parentDecision === 'declined';
                  const isPendingParent = rep.parentDecision === 'pending';

                  return (
                    <tr key={rep.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 pr-2">
                        <strong className="text-slate-900 block">{rep.tutorName}</strong>
                        <span className="text-xs text-slate-500">Student: {rep.studentName}</span>
                      </td>
                      <td className="py-3.5 px-2">
                        <span className="font-semibold text-slate-800 text-xs block">{rep.month}</span>
                        <span className="text-xs text-slate-500">{rep.totalHours} hrs &bull; {rep.overallScore.split(' ')[0]}</span>
                      </td>
                      <td className="py-3.5 px-2 max-w-xs">
                        <p className="text-xs text-slate-700 line-clamp-2">{rep.strengths}</p>
                      </td>
                      <td className="py-3.5 px-2">
                        {isApprovedForParent ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                            Dispatched to Parent
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                            Pending Admin Review
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-2">
                        {isAccepted && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Accepted by Parent
                          </span>
                        )}
                        {isDeclined && (
                          <div>
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                              <XCircle className="w-3.5 h-3.5" /> Declined by Parent
                            </span>
                            {rep.parentFeedback && (
                              <p className="text-[11px] text-rose-600 mt-1 italic line-clamp-1">
                                "{rep.parentFeedback}"
                              </p>
                            )}
                          </div>
                        )}
                        {isPendingParent && isApprovedForParent && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                            <Clock className="w-3.5 h-3.5" /> Awaiting Parent
                          </span>
                        )}
                        {!isApprovedForParent && (
                          <span className="text-xs text-slate-400">-</span>
                        )}
                      </td>
                      <td className="py-3.5 pl-2 text-right">
                        {!isApprovedForParent ? (
                          <button
                            onClick={() => handleReportApprove(rep.id)}
                            className="px-3 py-1.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-xs transition-colors"
                          >
                            ✔ Approve &amp; Send to Parent
                          </button>
                        ) : (
                          <span className="text-xs text-slate-400 font-medium">Dispatched</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: TUTORING JOBS & APPLICATIONS */}
      {activeTab === 'jobs' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Tutor Job Applications</h3>
                <p className="text-xs text-slate-500">
                  Accept qualified tutors. Once accepted, their placement card unlocks prompting them for the 60% or 23% payment.
                </p>
              </div>
              <button
                onClick={onOpenNewJobModal}
                className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" /> Post New Job Opening
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold text-xs uppercase tracking-wider">
                    <th className="pb-3 pr-2">Job Opening</th>
                    <th className="pb-3 px-2">Applicant Tutor</th>
                    <th className="pb-3 px-2">Cover Note</th>
                    <th className="pb-3 px-2">Status</th>
                    <th className="pb-3 pl-2 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {applications.map((app) => {
                    const isApproved = app.status === 'approved';
                    const isDeclined = app.status === 'declined';
                    const isPending = app.status === 'pending';

                    return (
                      <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3.5 pr-2">
                          <strong className="text-slate-900 block">{app.jobTitle}</strong>
                          <span className="text-xs text-slate-500 font-mono">App #{app.id}</span>
                        </td>
                        <td className="py-3.5 px-2">
                          <strong className="text-slate-800 block">{app.tutorName}</strong>
                          <span className="text-xs text-slate-500">{app.tutorEmail}</span>
                        </td>
                        <td className="py-3.5 px-2 max-w-xs">
                          <p className="text-xs text-slate-600 line-clamp-2">{app.coverNote}</p>
                        </td>
                        <td className="py-3.5 px-2">
                          {isApproved ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Accepted for Job
                            </span>
                          ) : isDeclined ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                              <XCircle className="w-3.5 h-3.5" /> Declined
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                              <Clock className="w-3.5 h-3.5" /> Pending Review
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 pl-2 text-right">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              onClick={() => handleAppAction(app.id, 'approved')}
                              className="px-2.5 py-1 rounded-lg text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 transition-colors"
                            >
                              ✔ Accept Tutor
                            </button>
                            <button
                              onClick={() => handleAppAction(app.id, 'declined')}
                              className="px-2.5 py-1 rounded-lg text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-300 transition-colors"
                            >
                              ✖ Decline
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Current Active Job Postings List */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h4 className="text-base font-bold text-slate-900">Current Job Openings ({jobs.length})</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {jobs.map((job) => (
                <div key={job.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between mb-1">
                    <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-blue-100 text-blue-800">
                      {job.grade}
                    </span>
                    <span className="text-xs font-extrabold text-emerald-700">
                      {job.rate}
                    </span>
                  </div>
                  <h5 className="font-bold text-slate-900 text-sm">{job.title}</h5>
                  <p className="text-xs text-slate-500 mt-1">
                    📍 {job.location} &bull; 🗓 {job.schedule}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: SUB-ADMIN ROLE ASSIGNMENT & PRIVACY ISOLATION BOARD */}
      {activeTab === 'roles' && (
        <div className="space-y-6">
          
          {/* Board Overview Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="p-1 rounded-md bg-purple-100 text-purple-800 text-xs font-bold flex items-center gap-1">
                    <Shield className="w-3.5 h-3.5" /> ACCESS GOVERNANCE
                  </span>
                  <span className="text-xs text-slate-500 font-medium">Role-Based Access Control (RBAC)</span>
                </div>
                <h3 className="text-xl font-black text-slate-900">
                  Sub-Admin Role Assignment &amp; Privacy Isolation Board
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-3xl leading-relaxed">
                  The Main Executive Administrator delegates operational responsibilities while enforcing strict privacy isolation. Sub-admins can only access the workspaces permitted by their assigned designation.
                </p>
              </div>

              {canAssignRoles ? (
                <button
                  onClick={handleOpenAddSubAdmin}
                  className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-purple-600 hover:bg-purple-700 text-white transition-all shadow-sm flex items-center gap-2 shrink-0 self-start sm:self-center"
                >
                  <Plus className="w-4 h-4" />
                  <span>Provision New Sub-Admin</span>
                </button>
              ) : (
                <div className="px-3 py-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold flex items-center gap-2">
                  <Lock className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Read-Only: Only the Main Super Admin can alter role permissions.</span>
                </div>
              )}
            </div>

            {/* Sub-Admin Statistics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                <p className="text-xs font-semibold text-slate-500">Authorized Staff</p>
                <p className="text-xl font-black text-slate-900">{subAdmins.length}</p>
              </div>
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200/80">
                <p className="text-xs font-semibold text-emerald-700">Active Sub-Admins</p>
                <p className="text-xl font-black text-emerald-900">
                  {subAdmins.filter(s => s.status === 'active').length}
                </p>
              </div>
              <div className="p-3 bg-blue-50 rounded-xl border border-blue-200/80">
                <p className="text-xs font-semibold text-blue-700">Academic &amp; Tutors</p>
                <p className="text-xl font-black text-blue-900">
                  {subAdmins.filter(s => s.designation === 'academic_coordinator').length}
                </p>
              </div>
              <div className="p-3 bg-purple-50 rounded-xl border border-purple-200/80">
                <p className="text-xs font-semibold text-purple-700">Finance &amp; Accounts</p>
                <p className="text-xl font-black text-purple-900">
                  {subAdmins.filter(s => s.designation === 'finance_officer').length}
                </p>
              </div>
            </div>
          </div>

          {/* Sub-Admin Directory & Permissions Matrix */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-bold text-slate-900">
                Active Staff Roster &amp; Permission Scopes ({subAdmins.length})
              </h4>
              <span className="text-xs text-slate-500">
                Privacy boundaries are enforced on client and view routing
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {subAdmins.map((admin) => {
                const isFounder = admin.id === 'admin-super-1';
                const isActive = admin.status === 'active';

                const badgeStyle = 
                  admin.designation === 'super_admin' ? 'bg-indigo-100 text-indigo-800 border-indigo-200' :
                  admin.designation === 'academic_coordinator' ? 'bg-blue-100 text-blue-800 border-blue-200' :
                  admin.designation === 'finance_officer' ? 'bg-emerald-100 text-emerald-800 border-emerald-200' :
                  'bg-purple-100 text-purple-800 border-purple-200';

                return (
                  <div 
                    key={admin.id} 
                    className={`p-5 rounded-2xl border transition-all ${
                      isActive 
                        ? 'bg-white border-slate-200 shadow-xs' 
                        : 'bg-slate-50 border-slate-200/70 opacity-75'
                    }`}
                  >
                    {/* Header */}
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase tracking-wider border ${badgeStyle}`}>
                            {admin.roleTitle}
                          </span>
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold flex items-center gap-1 ${
                            isActive ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                            {isActive ? 'Active' : 'Suspended'}
                          </span>
                        </div>
                        <h5 className="font-black text-slate-900 text-base flex items-center gap-1.5">
                          {admin.name}
                          {isFounder && (
                            <span className="text-[10px] text-amber-700 bg-amber-100 px-1.5 py-0.2 rounded font-bold">
                              Founder Root
                            </span>
                          )}
                        </h5>
                        <p className="text-xs text-slate-500 mt-0.5">
                          ✉ {admin.email} &bull; 📞 {admin.phone}
                        </p>
                      </div>

                      {/* Controls */}
                      {canAssignRoles && (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleOpenEditSubAdmin(admin)}
                            className="p-1.5 rounded-lg text-slate-600 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                            title="Edit Sub-Admin Permissions"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          {!isFounder && (
                            <>
                              <button
                                onClick={() => handleToggleSubAdminStatus(admin.id)}
                                className={`p-1.5 rounded-lg transition-colors ${
                                  isActive 
                                    ? 'text-amber-600 hover:bg-amber-50' 
                                    : 'text-emerald-600 hover:bg-emerald-50'
                                }`}
                                title={isActive ? 'Suspend Sub-Admin' : 'Activate Sub-Admin'}
                              >
                                {isActive ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                              </button>

                              <button
                                onClick={() => handleDeleteSubAdmin(admin.id)}
                                className="p-1.5 rounded-lg text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition-colors"
                                title="Revoke Sub-Admin Access"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Permissions Matrix */}
                    <div className="pt-3 border-t border-slate-100 space-y-1.5">
                      <p className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                        Configured Access Scope:
                      </p>
                      <div className="grid grid-cols-2 gap-1.5 text-xs">
                        <div className={`flex items-center gap-1.5 p-1.5 rounded-lg ${
                          admin.permissions.canVerifyPayments ? 'bg-emerald-50 text-emerald-800 font-semibold' : 'bg-slate-100 text-slate-400'
                        }`}>
                          {admin.permissions.canVerifyPayments ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <span className="w-3.5 text-center text-slate-400 font-mono">-</span>}
                          <span>Parent Payments</span>
                        </div>

                        <div className={`flex items-center gap-1.5 p-1.5 rounded-lg ${
                          admin.permissions.canVerifyTutors ? 'bg-emerald-50 text-emerald-800 font-semibold' : 'bg-slate-100 text-slate-400'
                        }`}>
                          {admin.permissions.canVerifyTutors ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <span className="w-3.5 text-center text-slate-400 font-mono">-</span>}
                          <span>Tutor 500 ETB Vetting</span>
                        </div>

                        <div className={`flex items-center gap-1.5 p-1.5 rounded-lg ${
                          admin.permissions.canPostJobs ? 'bg-emerald-50 text-emerald-800 font-semibold' : 'bg-slate-100 text-slate-400'
                        }`}>
                          {admin.permissions.canPostJobs ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <span className="w-3.5 text-center text-slate-400 font-mono">-</span>}
                          <span>Post Tutoring Jobs</span>
                        </div>

                        <div className={`flex items-center gap-1.5 p-1.5 rounded-lg ${
                          admin.permissions.canApproveReports ? 'bg-emerald-50 text-emerald-800 font-semibold' : 'bg-slate-100 text-slate-400'
                        }`}>
                          {admin.permissions.canApproveReports ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <span className="w-3.5 text-center text-slate-400 font-mono">-</span>}
                          <span>Monthly Reports</span>
                        </div>

                        <div className={`flex items-center gap-1.5 p-1.5 rounded-lg ${
                          admin.permissions.canManageApplications ? 'bg-emerald-50 text-emerald-800 font-semibold' : 'bg-slate-100 text-slate-400'
                        }`}>
                          {admin.permissions.canManageApplications ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <span className="w-3.5 text-center text-slate-400 font-mono">-</span>}
                          <span>Tutor Applications</span>
                        </div>

                        <div className={`flex items-center gap-1.5 p-1.5 rounded-lg ${
                          admin.permissions.canAssignRoles ? 'bg-purple-50 text-purple-800 font-bold' : 'bg-slate-100 text-slate-400'
                        }`}>
                          {admin.permissions.canAssignRoles ? <Check className="w-3.5 h-3.5 text-purple-600" /> : <span className="w-3.5 text-center text-slate-400 font-mono">-</span>}
                          <span>Role Assignment</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 pt-2 text-[10px] text-slate-400 flex items-center justify-between border-t border-slate-100">
                      <span>Added: {admin.addedAt}</span>
                      <span>Status: {admin.lastActive || 'Active'}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* PROVISION / EDIT SUB-ADMIN MODAL */}
      {isSubAdminModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-fade-in">
            
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-6 relative">
              <button
                onClick={() => setIsSubAdminModalOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white px-2 py-1 rounded-md text-xs font-bold"
              >
                ✕
              </button>
              <div className="flex items-center gap-2 mb-1">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                  {editingSubAdminId ? 'Modify Access Rights' : 'Staff Delegation'}
                </span>
              </div>
              <h3 className="text-xl font-black text-white">
                {editingSubAdminId ? 'Edit Sub-Admin Permissions' : 'Provision New Sub-Administrator'}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Assign specific operational duties and ensure privacy-isolated module boundaries.
              </p>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveSubAdmin} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Staff Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={subAdminForm.name}
                    onChange={e => setSubAdminForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Dr. Alula Kebede"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Staff Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={subAdminForm.email}
                    onChange={e => setSubAdminForm(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="academic@adortutorial.com"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={subAdminForm.phone}
                    onChange={e => setSubAdminForm(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="+251 91 222 3344"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Role Designation Preset
                  </label>
                  <select
                    value={subAdminForm.designation}
                    onChange={e => {
                      const des = e.target.value as AdminDesignation;
                      let title = 'Sub-Admin';
                      let perms: AdminPermissions = {
                        canVerifyPayments: false,
                        canVerifyTutors: false,
                        canPostJobs: false,
                        canApproveReports: false,
                        canManageApplications: false,
                        canAssignRoles: false,
                      };

                      if (des === 'academic_coordinator') {
                        title = 'Academic Director & Curriculum Matcher';
                        perms = {
                          canVerifyPayments: false,
                          canVerifyTutors: true,
                          canPostJobs: true,
                          canApproveReports: true,
                          canManageApplications: true,
                          canAssignRoles: false,
                        };
                      } else if (des === 'finance_officer') {
                        title = 'Finance & Bank Verification Officer';
                        perms = {
                          canVerifyPayments: true,
                          canVerifyTutors: false,
                          canPostJobs: false,
                          canApproveReports: false,
                          canManageApplications: false,
                          canAssignRoles: false,
                        };
                      } else if (des === 'counselor') {
                        title = 'Student & Parent Academic Counselor';
                        perms = {
                          canVerifyPayments: false,
                          canVerifyTutors: false,
                          canPostJobs: false,
                          canApproveReports: true,
                          canManageApplications: false,
                          canAssignRoles: false,
                        };
                      } else if (des === 'operations_manager') {
                        title = 'Operations & Job Postings Manager';
                        perms = {
                          canVerifyPayments: false,
                          canVerifyTutors: true,
                          canPostJobs: true,
                          canApproveReports: false,
                          canManageApplications: true,
                          canAssignRoles: false,
                        };
                      } else if (des === 'super_admin') {
                        title = 'Super Administrator';
                        perms = {
                          canVerifyPayments: true,
                          canVerifyTutors: true,
                          canPostJobs: true,
                          canApproveReports: true,
                          canManageApplications: true,
                          canAssignRoles: true,
                        };
                      }

                      setSubAdminForm(prev => ({
                        ...prev,
                        designation: des,
                        roleTitle: title,
                        permissions: perms,
                      }));
                    }}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="academic_coordinator">Academic Coordinator (Curriculum & Tutors)</option>
                    <option value="finance_officer">Finance Officer (Bank & Telebirr Verification)</option>
                    <option value="counselor">Student & Parent Counselor (Progress Reports)</option>
                    <option value="operations_manager">Operations Manager (Job Postings)</option>
                    <option value="super_admin">Super Administrator (Unrestricted)</option>
                  </select>
                </div>
              </div>

              {/* Granular Permissions Checkboxes */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Granular Permission Switches:
                </label>

                <div className="space-y-2">
                  <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={subAdminForm.permissions.canVerifyPayments}
                      onChange={e => setSubAdminForm(prev => ({
                        ...prev,
                        permissions: { ...prev.permissions, canVerifyPayments: e.target.checked }
                      }))}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                    />
                    <span><strong>Verify Parent Payments:</strong> View Telebirr/CBE receipts and update payment statuses</span>
                  </label>

                  <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={subAdminForm.permissions.canVerifyTutors}
                      onChange={e => setSubAdminForm(prev => ({
                        ...prev,
                        permissions: { ...prev.permissions, canVerifyTutors: e.target.checked }
                      }))}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                    />
                    <span><strong>Verify Tutor Memberships:</strong> Review 21-point tutor applications and 500 ETB receipts</span>
                  </label>

                  <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={subAdminForm.permissions.canPostJobs}
                      onChange={e => setSubAdminForm(prev => ({
                        ...prev,
                        permissions: { ...prev.permissions, canPostJobs: e.target.checked }
                      }))}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                    />
                    <span><strong>Post Tutoring Openings:</strong> Create, publish, and edit tutoring jobs</span>
                  </label>

                  <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={subAdminForm.permissions.canApproveReports}
                      onChange={e => setSubAdminForm(prev => ({
                        ...prev,
                        permissions: { ...prev.permissions, canApproveReports: e.target.checked }
                      }))}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                    />
                    <span><strong>Approve Student Reports:</strong> Quality check tutor feedback and release to parents</span>
                  </label>

                  <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={subAdminForm.permissions.canManageApplications}
                      onChange={e => setSubAdminForm(prev => ({
                        ...prev,
                        permissions: { ...prev.permissions, canManageApplications: e.target.checked }
                      }))}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
                    />
                    <span><strong>Accept / Decline Tutors:</strong> Match tutors to jobs and unlock commission contracts</span>
                  </label>

                  <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      disabled={!isSuperAdmin}
                      checked={subAdminForm.permissions.canAssignRoles}
                      onChange={e => setSubAdminForm(prev => ({
                        ...prev,
                        permissions: { ...prev.permissions, canAssignRoles: e.target.checked }
                      }))}
                      className="rounded text-purple-600 focus:ring-purple-500 w-4 h-4 disabled:opacity-50"
                    />
                    <span><strong>Assign Roles &amp; Sub-Admins:</strong> Super Admin authority to provision staff (Master Only)</span>
                  </label>
                </div>
              </div>

              {/* Modal Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsSubAdminModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white transition-colors shadow-xs"
                >
                  {editingSubAdminId ? 'Save Updated Permissions' : 'Authorize & Provision Sub-Admin'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { CurrentUser, AdminDesignation } from '../types';
import { TranslationDictionary } from '../data/translations';
import { AdorLogo } from './AdorLogo';
import { ShieldCheck, UserCheck, GraduationCap, Lock, ArrowRight } from 'lucide-react';

export interface SignInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSignIn: (user: CurrentUser) => void;
  onOpenSignUp: (role?: 'parent' | 'tutor') => void;
  targetRole?: 'parent' | 'tutor' | 'admin';
  t: TranslationDictionary;
}

export const SignInModal: React.FC<SignInModalProps> = ({
  isOpen,
  onClose,
  onSignIn,
  onOpenSignUp,
  targetRole = 'parent',
  t,
}) => {
  const [selectedRole, setSelectedRole] = useState<'parent' | 'tutor' | 'admin'>(targetRole);
  const [adminDesignation, setAdminDesignation] = useState<AdminDesignation>('super_admin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('••••••••');

  // Preset accounts with verified credentials
  const demoAccounts = {
    parent: {
      id: 'demo-parent-1',
      role: 'parent' as const,
      name: 'Dr. Elias Solomon',
      email: 'elias.solomon@gmail.com',
      phone: '0911234567',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
      isVerified: true,
    },
    tutor: {
      id: 'demo-tutor-1',
      role: 'tutor' as const,
      name: 'Abebe Kebede (MSc)',
      email: 'abebe.kebede@gmail.com',
      phone: '0912345678',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
      isVerified: true,
    },
    admin: {
      super_admin: {
        id: 'admin-super-1',
        role: 'admin' as const,
        adminDesignation: 'super_admin' as const,
        name: 'Executive Director (Main Admin)',
        email: 'admin@adortutorial.com',
        phone: '0900000000',
        avatarUrl: 'https://images.unsplash.com/photo-1531384441138-2736e62e0919?auto=format&fit=crop&w=400&q=80',
        isVerified: true,
        permissions: {
          canVerifyPayments: true,
          canVerifyTutors: true,
          canPostJobs: true,
          canApproveReports: true,
          canManageApplications: true,
          canAssignRoles: true,
        }
      },
      academic_coordinator: {
        id: 'admin-acad-2',
        role: 'admin' as const,
        adminDesignation: 'academic_coordinator' as const,
        name: 'Dr. Alula Kebede (MSc, PhD)',
        email: 'academic@adortutorial.com',
        phone: '0912223344',
        avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
        isVerified: true,
        permissions: {
          canVerifyPayments: false,
          canVerifyTutors: true,
          canPostJobs: true,
          canApproveReports: true,
          canManageApplications: true,
          canAssignRoles: false,
        }
      },
      finance_officer: {
        id: 'admin-fin-3',
        role: 'admin' as const,
        adminDesignation: 'finance_officer' as const,
        name: 'Selamawit Tadesse (BA Acc)',
        email: 'finance@adortutorial.com',
        phone: '0913334455',
        avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
        isVerified: true,
        permissions: {
          canVerifyPayments: true,
          canVerifyTutors: false,
          canPostJobs: false,
          canApproveReports: false,
          canManageApplications: false,
          canAssignRoles: false,
        }
      }
    }
  };

  // Sync role and demo email whenever modal opens or targetRole changes
  useEffect(() => {
    const role = targetRole || 'parent';
    setSelectedRole(role);
    if (role === 'parent') {
      setEmail(demoAccounts.parent.email);
    } else if (role === 'tutor') {
      setEmail(demoAccounts.tutor.email);
    } else if (role === 'admin') {
      setEmail(demoAccounts.admin[adminDesignation].email);
    }
  }, [targetRole, isOpen]);

  if (!isOpen) return null;

  const handleQuickLogin = (role: 'parent' | 'tutor' | 'admin') => {
    if (role === 'admin') {
      onSignIn(demoAccounts.admin[adminDesignation]);
    } else {
      onSignIn(demoAccounts[role]);
    }
    onClose();
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedRole === 'admin') {
      const targetPreset = demoAccounts.admin[adminDesignation];
      const user: CurrentUser = {
        id: targetPreset.id,
        role: 'admin',
        adminDesignation,
        name: targetPreset.name,
        email: email || targetPreset.email,
        phone: targetPreset.phone,
        isVerified: true,
        permissions: targetPreset.permissions,
      };
      onSignIn(user);
    } else {
      const user: CurrentUser = {
        id: `usr-${Date.now()}`,
        role: selectedRole,
        name: email.split('@')[0] || (selectedRole === 'parent' ? 'Registered Parent' : 'Verified Tutor'),
        email: email || demoAccounts[selectedRole].email,
        phone: '0911000000',
        isVerified: true,
      };
      onSignIn(user);
    }
    onClose();
  };

  // Role-specific theme styling & textual labels
  const roleConfig = {
    parent: {
      gradient: 'from-blue-900 via-blue-800 to-slate-900',
      tagText: 'Parent & Guardian Portal',
      tagBadge: 'bg-blue-500/20 text-blue-200 border-blue-400/30',
      title: 'Parent & Student Sign In',
      subtitle: 'Track your child\'s home tutoring sessions, monthly payments, and academic reports',
      demoTitle: 'Quick Demo: Dr. Elias Solomon (Parent)',
      demoSub: 'Pre-configured authorized parent account',
      signUpPrompt: 'Register',
      icon: <UserCheck className="w-5 h-5 text-blue-300" />,
      submitBtnClass: 'bg-blue-700 hover:bg-blue-800 text-white',
    },
    tutor: {
      gradient: 'from-blue-950 via-blue-800 to-slate-900',
      tagText: 'Certified Tutor Workspace',
      tagBadge: 'bg-blue-500/20 text-blue-200 border-blue-400/30',
      title: 'Certified Tutor Sign In',
      subtitle: 'Access tutoring vacancies, track 60%/23% commissions, and dispatch evaluations',
      demoTitle: 'Quick Demo: Abebe Kebede MSc (Tutor)',
      demoSub: 'Pre-configured certified educator account',
      signUpPrompt: 'Register',
      icon: <GraduationCap className="w-5 h-5 text-blue-300" />,
      submitBtnClass: 'bg-blue-700 hover:bg-blue-800 text-white',
    },
    admin: {
      gradient: 'from-slate-950 via-indigo-950 to-slate-900',
      tagText: 'Executive Management Console',
      tagBadge: 'bg-amber-400/20 text-amber-200 border-amber-400/30',
      title: 'Staff & Administrator Sign In',
      subtitle: 'Authorized executive supervision console for Ador Tutorial Center operations',
      demoTitle: `Quick Demo: ${demoAccounts.admin[adminDesignation].name}`,
      demoSub: `Access: ${adminDesignation === 'super_admin' ? 'Super Administrator (Master Access)' : adminDesignation === 'academic_coordinator' ? 'Academic Sub-Admin (Isolated)' : 'Finance Sub-Admin (Isolated)'}`,
      signUpPrompt: '',
      icon: <ShieldCheck className="w-5 h-5 text-amber-400" />,
      submitBtnClass: 'bg-indigo-700 hover:bg-indigo-800 text-white',
    }
  };

  const currentConfig = roleConfig[selectedRole];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-fade-in">
        
        {/* Role-Specific Header Banner */}
        <div className={`bg-gradient-to-r ${currentConfig.gradient} text-white p-6 text-center relative`}>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white px-2.5 py-1 rounded-lg hover:bg-white/10 transition-colors text-xs font-bold"
          >
            ✕
          </button>

          <div className="flex justify-center mb-3">
            <AdorLogo size="md" variant="mark" />
          </div>

          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border mb-2 mx-auto shadow-2xs backdrop-blur-xs">
            {currentConfig.icon}
            <span className={currentConfig.tagBadge}>{currentConfig.tagText}</span>
          </div>

          <h2 className="text-xl font-black tracking-tight">
            {currentConfig.title}
          </h2>
          <p className="text-xs text-slate-200/90 mt-1 max-w-xs mx-auto leading-relaxed">
            {currentConfig.subtitle}
          </p>
        </div>

        <div className="p-6 space-y-4">
          
          {/* If Admin is selected, display Sub-Admin Designation selector */}
          {selectedRole === 'admin' && (
            <div className="bg-indigo-50/60 p-3.5 rounded-xl border border-indigo-100 space-y-2">
              <label className="block text-[11px] font-bold text-indigo-900 uppercase tracking-wider">
                Select Administrative Role &amp; Access Level:
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setAdminDesignation('super_admin');
                    setEmail(demoAccounts.admin.super_admin.email);
                  }}
                  className={`px-2 py-2 rounded-lg text-xs font-bold transition-all text-center border ${
                    adminDesignation === 'super_admin'
                      ? 'bg-indigo-600 text-white border-indigo-700 shadow-2xs'
                      : 'bg-white text-indigo-900 border-indigo-200 hover:bg-indigo-100/60'
                  }`}
                >
                  <p className="text-[11px]">Super Admin</p>
                  <p className="text-[9px] font-normal opacity-90">Master Access</p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setAdminDesignation('academic_coordinator');
                    setEmail(demoAccounts.admin.academic_coordinator.email);
                  }}
                  className={`px-2 py-2 rounded-lg text-xs font-bold transition-all text-center border ${
                    adminDesignation === 'academic_coordinator'
                      ? 'bg-indigo-600 text-white border-indigo-700 shadow-2xs'
                      : 'bg-white text-indigo-900 border-indigo-200 hover:bg-indigo-100/60'
                  }`}
                >
                  <p className="text-[11px]">Academic</p>
                  <p className="text-[9px] font-normal opacity-90">Tutors &amp; Reports</p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setAdminDesignation('finance_officer');
                    setEmail(demoAccounts.admin.finance_officer.email);
                  }}
                  className={`px-2 py-2 rounded-lg text-xs font-bold transition-all text-center border ${
                    adminDesignation === 'finance_officer'
                      ? 'bg-indigo-600 text-white border-indigo-700 shadow-2xs'
                      : 'bg-white text-indigo-900 border-indigo-200 hover:bg-indigo-100/60'
                  }`}
                >
                  <p className="text-[11px]">Finance</p>
                  <p className="text-[9px] font-normal opacity-90">Payments &amp; Fees</p>
                </button>
              </div>
            </div>
          )}

          {/* Quick Demo Sign In Box */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs flex items-center justify-between gap-3 shadow-2xs">
            <div className="min-w-0 flex-1">
              <p className="font-bold text-slate-800 truncate">
                {currentConfig.demoTitle}
              </p>
              <p className="text-[11px] text-slate-500 truncate">
                {currentConfig.demoSub}
              </p>
            </div>
            <button
              onClick={() => handleQuickLogin(selectedRole)}
              className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors shadow-xs whitespace-nowrap shrink-0"
            >
              Instant Sign In ➔
            </button>
          </div>

          <div className="relative flex items-center justify-center my-2">
            <div className="border-t border-slate-200 w-full" />
            <span className="bg-white px-2 text-[10px] uppercase tracking-wider text-slate-400 font-bold">
              Or sign in with email
            </span>
            <div className="border-t border-slate-200 w-full" />
          </div>

          {/* Custom Credentials Form */}
          <form onSubmit={handleCustomSubmit} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {selectedRole === 'parent' ? 'Parent Email Address' : selectedRole === 'tutor' ? 'Tutor Email Address' : 'Staff Email Address'}
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder={selectedRole === 'parent' ? 'parent@gmail.com' : selectedRole === 'tutor' ? 'tutor@gmail.com' : 'admin@adortutorial.com'}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Password
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              type="submit"
              className={`w-full py-2.5 rounded-xl font-bold text-xs transition-colors shadow-xs uppercase tracking-wide flex items-center justify-center gap-1.5 ${currentConfig.submitBtnClass}`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Sign In as {selectedRole === 'parent' ? 'Parent' : selectedRole === 'tutor' ? 'Tutor' : 'Admin'}</span>
            </button>
          </form>

          {/* Role-Specific Sign Up Call-To-Action (Avoids 'Select Your Official Account Role') */}
          {selectedRole !== 'admin' && (
            <div className="pt-2 text-center text-xs text-slate-600 border-t border-slate-100">
              <p className="text-[11px] text-slate-500 mb-1">Don't have an account yet?</p>
              <button
                onClick={() => {
                  onClose();
                  onOpenSignUp(selectedRole);
                }}
                className="font-bold hover:underline inline-flex items-center gap-1 text-blue-700"
              >
                <span>{currentConfig.signUpPrompt}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          )}

          {/* Subtle switcher if user clicked wrong portal */}
          <div className="pt-1 text-center text-[11px] text-slate-400">
            {selectedRole === 'parent' && (
              <button
                type="button"
                onClick={() => {
                  setSelectedRole('tutor');
                  setEmail(demoAccounts.tutor.email);
                }}
                className="hover:text-slate-700 underline"
              >
                Looking for Tutor Workspace sign in instead?
              </button>
            )}
            {selectedRole === 'tutor' && (
              <button
                type="button"
                onClick={() => {
                  setSelectedRole('parent');
                  setEmail(demoAccounts.parent.email);
                }}
                className="hover:text-slate-700 underline"
              >
                Looking for Parent Portal sign in instead?
              </button>
            )}
            {selectedRole === 'admin' && (
              <span className="text-slate-400">
                Staff accounts are provisioned exclusively by the Main Super Administrator.
              </span>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};


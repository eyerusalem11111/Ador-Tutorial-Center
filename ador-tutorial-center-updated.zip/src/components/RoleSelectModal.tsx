import React from 'react';
import { AdorLogo } from './AdorLogo';

interface RoleSelectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectParent: () => void;
  onSelectTutor: () => void;
  onOpenSignIn: () => void;
}

export const RoleSelectModal: React.FC<RoleSelectModalProps> = ({
  isOpen,
  onClose,
  onSelectParent,
  onSelectTutor,
  onOpenSignIn,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white p-6 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white px-2 py-0.5 rounded-lg hover:bg-white/10 transition-colors text-xs font-bold"
          >
            ✕
          </button>

          <div className="flex justify-center mb-3">
            <AdorLogo size="md" variant="mark" />
          </div>

          <h2 className="text-xl sm:text-2xl font-black tracking-tight">
            Register Now
          </h2>
          <p className="text-xs sm:text-sm text-blue-100/80 mt-1">
            Select your pathway to request a certified home tutor or apply as an educator
          </p>
        </div>

        {/* Pathway Selection - Clean typographic design avoiding icons */}
        <div className="p-6 space-y-4">
          
          {/* Option 1: Student / Parent (19 Requests) */}
          <div 
            onClick={() => {
              onClose();
              onSelectParent();
            }}
            className="p-5 rounded-2xl border-2 border-blue-200 hover:border-blue-600 bg-blue-50/40 hover:bg-blue-50 transition-all cursor-pointer group shadow-2xs space-y-2"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-slate-900 group-hover:text-blue-700 transition-colors">
                Student &amp; Parent Registration
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold uppercase">
                Student &amp; Parent Intake
              </span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Request a certified 1-on-1 home tutor for Kindergarten through Grade 12 or National Ministry Exam Preparation.
            </p>
            <div className="pt-2 text-xs font-bold text-blue-700">
              Start Parent Registration ➔
            </div>
          </div>

          {/* Option 2: Professional Tutor */}
          <div 
            onClick={() => {
              onClose();
              onSelectTutor();
            }}
            className="p-5 rounded-2xl border-2 border-blue-200 hover:border-blue-600 bg-blue-50/40 hover:bg-blue-50 transition-all cursor-pointer group shadow-2xs space-y-2"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-slate-900 group-hover:text-blue-700 transition-colors">
                Tutor Application &amp; Accreditation
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold uppercase">
                Educator Accreditation
              </span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Apply for high-paying home and online tutoring placements across Addis Ababa families.
            </p>
            <div className="pt-2 text-xs font-bold text-blue-700">
              Start Tutor Application ➔
            </div>
          </div>

          {/* Footer with sign in switch */}
          <div className="pt-3 text-center text-xs text-slate-500 border-t border-slate-100">
            <span>Already have an account? </span>
            <button
              onClick={() => {
                onClose();
                onOpenSignIn();
              }}
              className="text-blue-700 font-bold hover:underline"
            >
              Sign In to Your Dashboard
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};

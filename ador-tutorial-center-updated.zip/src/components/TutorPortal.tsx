import React, { useState } from 'react';
import { TutorProfile, TutoringJob, JobApplication, MonthlyReport } from '../types';
import { createReceiptPlaceholder } from '../data/initialData';
import { 
  Briefcase, 
  FileEdit, 
  ClipboardList, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Upload, 
  Sparkles, 
  Send, 
  Search, 
  DollarSign, 
  MapPin, 
  BookOpen, 
  Award, 
  Eye, 
  ArrowUpRight,
  ShieldCheck,
  Percent,
  Check,
  Copy
} from 'lucide-react';

interface TutorPortalProps {
  tutor: TutorProfile;
  jobs: TutoringJob[];
  applications: JobApplication[];
  reports: MonthlyReport[];
  onUpdateMembership: (data: { method: string; reference: string; receiptUrl: string }) => void;
  onApplyJob: (jobId: string, coverNote: string) => void;
  onSubmitCommission: (applicationId: string, choice: '60_percent_first_month' | '23_percent_monthly', method: string, reference: string, receiptUrl: string) => void;
  onSubmitReport: (report: Omit<MonthlyReport, 'id' | 'tutorId' | 'tutorName' | 'status' | 'parentDecision' | 'submittedDate'>) => void;
  onViewReceipt: (receiptUrl: string, details: any) => void;
  showToast: (type: 'success' | 'error' | 'info', message: string, title?: string) => void;
}

export const TutorPortal: React.FC<TutorPortalProps> = ({
  tutor,
  jobs,
  applications,
  reports,
  onUpdateMembership,
  onApplyJob,
  onSubmitCommission,
  onSubmitReport,
  onViewReceipt,
  showToast,
}) => {
  const [activeTab, setActiveTab] = useState<'jobs' | 'submit-report' | 'history'>('jobs');

  // 500 ETB Membership form state
  const [membershipMethod, setMembershipMethod] = useState('Telebirr');
  const [membershipRef, setMembershipRef] = useState('');
  const [membershipReceiptUrl, setMembershipReceiptUrl] = useState<string | null>(null);

  // Commission Submission form states per application
  const [selectedChoices, setSelectedChoices] = useState<Record<string, '60_percent_first_month' | '23_percent_monthly'>>({});
  const [commissionMethods, setCommissionMethods] = useState<Record<string, string>>({});
  const [commissionRefs, setCommissionRefs] = useState<Record<string, string>>({});
  const [commissionReceipts, setCommissionReceipts] = useState<Record<string, string>>({});

  // Job Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSubject, setFilterSubject] = useState('all');

  // Apply note state
  const [applyingJobId, setApplyingJobId] = useState<string | null>(null);
  const [coverNote, setCoverNote] = useState('');

  // Submit Monthly Report State
  const [reportStudentName, setReportStudentName] = useState('Samuel Kassahun');
  const [reportParentEmail, setReportParentEmail] = useState('almaz.m@gmail.com');
  const [reportMonth, setReportMonth] = useState('Second Month (Tikimt / Month 2)');
  const [reportHours, setReportHours] = useState('16');
  const [reportScore, setReportScore] = useState<MonthlyReport['overallScore']>('Excellent (Straight A / 90%+)');
  const [reportStrengths, setReportStrengths] = useState('');
  const [reportImprovements, setReportImprovements] = useState('');
  const [isSubmittingReport, setIsSubmittingReport] = useState(false);

  // Sample receipt generator for 500 ETB membership
  const handleGenerateMembershipReceipt = () => {
    const ref = 'TB-MEMB-' + Math.floor(100000 + Math.random() * 900000);
    setMembershipRef(ref);
    const slip = createReceiptPlaceholder('telebirr', ref, '500.00', tutor.name, 'Tutor 500 ETB Membership Fee');
    setMembershipReceiptUrl(slip);
    showToast('success', 'Generated 500 ETB Telebirr receipt slip!');
  };

  const handleMembershipSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!membershipReceiptUrl) {
      showToast('error', 'Please attach a payment receipt screenshot.');
      return;
    }
    onUpdateMembership({
      method: membershipMethod,
      reference: membershipRef || ('TXN-MB-' + Math.floor(100000 + Math.random() * 900000)),
      receiptUrl: membershipReceiptUrl,
    });
    showToast('success', '500 ETB membership receipt submitted for admin verification!', 'Verification Pending');
  };

  // Commission sample receipt generator
  const handleGenerateCommissionReceipt = (appId: string, amount: number) => {
    const ref = 'COMM-' + Math.floor(1000000 + Math.random() * 9000000);
    setCommissionRefs(prev => ({ ...prev, [appId]: ref }));
    const slip = createReceiptPlaceholder(
      'telebirr',
      ref,
      amount.toLocaleString('en-US', { minimumFractionDigits: 2 }),
      tutor.name,
      'Tutoring Placement Commission'
    );
    setCommissionReceipts(prev => ({ ...prev, [appId]: slip }));
    showToast('success', `Generated ${amount.toLocaleString()} ETB commission receipt slip!`);
  };

  const handleCommissionSubmit = (appId: string, defaultEstimate: number) => {
    const choice = selectedChoices[appId] || '60_percent_first_month';
    const method = commissionMethods[appId] || 'Telebirr';
    const ref = commissionRefs[appId] || ('TXN-' + Math.floor(1000000 + Math.random() * 9000000));
    let receipt = commissionReceipts[appId];

    if (!receipt) {
      // Auto-generate if missing so user has frictionless flow
      const amount = choice === '60_percent_first_month' ? defaultEstimate * 0.6 : defaultEstimate * 0.23;
      receipt = createReceiptPlaceholder('telebirr', ref, amount.toFixed(2), tutor.name, 'Tutoring Placement Commission');
    }

    onSubmitCommission(appId, choice, method, ref, receipt);
    showToast('success', 'Placement commission proof submitted for Ador Admin verification!', 'Commission Submitted');
  };

  const handleApplyClick = (job: TutoringJob) => {
    onApplyJob(job.id, coverNote || `Interested in tutoring ${job.subject} for ${job.grade}. Experienced in Ethiopian national & regional curriculum.`);
    setApplyingJobId(null);
    setCoverNote('');
    showToast('success', `Applied for "${job.title}" successfully!`);
  };

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportStudentName.trim() || !reportStrengths.trim() || !reportImprovements.trim()) {
      showToast('error', 'Please fill out all evaluation fields.');
      return;
    }

    setIsSubmittingReport(true);
    setTimeout(() => {
      onSubmitReport({
        studentName: reportStudentName,
        parentEmail: reportParentEmail,
        month: reportMonth,
        totalHours: parseInt(reportHours, 10) || 16,
        overallScore: reportScore,
        strengths: reportStrengths,
        improvements: reportImprovements,
      });

      setIsSubmittingReport(false);
      setReportStrengths('');
      setReportImprovements('');
      showToast('success', 'Monthly report submitted to Ador Admin for dispatch to parent!', 'Report Submitted');
      setActiveTab('history');
    }, 400);
  };

  // Filtered jobs
  const filteredJobs = jobs.filter(j => {
    const matchesSearch = j.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          j.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          j.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = filterSubject === 'all' || j.subject.toLowerCase().includes(filterSubject.toLowerCase());
    return matchesSearch && matchesSubject;
  });

  const myApplications = applications.filter(a => a.tutorId === tutor.id || a.tutorEmail === tutor.email);
  const acceptedApps = myApplications.filter(a => a.status === 'approved');
  const myReports = reports.filter(r => r.tutorId === tutor.id || r.tutorName === tutor.name);

  return (
    <div className="space-y-8 animate-fade-in pb-12">

      {/* 1. TUTOR MEMBERSHIP ONBOARDING (500 ETB FEE BANNER) */}
      {tutor.membershipStatus !== 'verified' && (
        <div className="bg-gradient-to-r from-amber-500/10 via-amber-50 to-orange-50 rounded-3xl p-6 sm:p-8 border-2 border-amber-300 shadow-sm relative overflow-hidden">
          <div className="flex flex-col md:flex-row items-start justify-between gap-6">
            <div className="space-y-3 flex-1">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-amber-500 text-white shadow-xs">
                  <Award className="w-5 h-5" />
                </span>
                <h3 className="text-xl font-extrabold text-slate-900">
                  Tutor Membership Activation (500 ETB Fee)
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Welcome to Ador Tutorial Center! Before receiving new student job placements and tutoring contracts, please complete the two-step verification below:
              </p>

              {/* Two Steps */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                <div className="p-3 bg-white rounded-xl border border-amber-200">
                  <span className="font-extrabold text-amber-800 flex items-center gap-1.5 mb-1">
                    <span className="w-5 h-5 rounded-full bg-amber-200 text-amber-900 flex items-center justify-center text-xs">1</span>
                    Review Terms on Telegram
                  </span>
                  <p className="text-slate-600 mb-2">
                    Visit our official Telegram account and confirm your instructor guidelines.
                  </p>
                  <a
                    href="https://t.me/AdorTutorCenter"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 font-bold text-blue-700 hover:underline"
                  >
                    Open @AdorTutorCenter <ArrowUpRight className="w-3 h-3" />
                  </a>
                </div>

                <div className="p-3 bg-white rounded-xl border border-amber-200">
                  <span className="font-extrabold text-amber-800 flex items-center gap-1.5 mb-1">
                    <span className="w-5 h-5 rounded-full bg-amber-200 text-amber-900 flex items-center justify-center text-xs">2</span>
                    500 ETB One-time Fee
                  </span>
                  <p className="text-slate-600 mb-1">
                    Pay via Telebirr or CBE to activate your teaching badge.
                  </p>
                  <p className="font-mono text-[11px] text-slate-500">
                    Telebirr: 0911 22 33 44 &bull; CBE: 1000 2938 49182
                  </p>
                </div>
              </div>
            </div>

            {/* Submission / Status Form */}
            <div className="w-full md:w-80 bg-white p-5 rounded-2xl border border-amber-200 shadow-sm shrink-0">
              {tutor.membershipStatus === 'pending_verification' ? (
                <div className="text-center py-4 space-y-2">
                  <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center mx-auto">
                    <Clock className="w-6 h-6 animate-pulse" />
                  </div>
                  <h4 className="text-sm font-bold text-slate-800">500 ETB Receipt Under Verification</h4>
                  <p className="text-xs text-slate-500">
                    Your payment receipt is being validated by Ador Administration. You will be activated shortly.
                  </p>
                  {tutor.membershipReceiptUrl && (
                    <button
                      onClick={() => onViewReceipt(tutor.membershipReceiptUrl!, {
                        payerOrStudent: tutor.name,
                        amount: 500,
                        method: tutor.membershipMethod,
                        reference: tutor.membershipReference,
                        monthOrPurpose: '500 ETB Tutor Membership Fee',
                        status: 'pending_verification',
                      })}
                      className="text-xs font-bold text-blue-700 hover:underline flex items-center justify-center gap-1 mx-auto pt-2"
                    >
                      <Eye className="w-3.5 h-3.5" /> View Uploaded Receipt
                    </button>
                  )}
                </div>
              ) : (
                <form onSubmit={handleMembershipSubmit} className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Submit 500 ETB Payment Proof
                  </h4>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Method</label>
                    <select
                      value={membershipMethod}
                      onChange={(e) => setMembershipMethod(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="Telebirr">Telebirr (0911 22 33 44)</option>
                      <option value="Commercial Bank of Ethiopia (CBE)">CBE (1000 2938 49182)</option>
                      <option value="Awash Bank">Awash Bank</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Transaction Ref</label>
                    <input
                      type="text"
                      value={membershipRef}
                      onChange={(e) => setMembershipRef(e.target.value)}
                      placeholder="e.g. TB123456"
                      className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-semibold text-slate-600">Receipt Screenshot</label>
                      <button
                        type="button"
                        onClick={handleGenerateMembershipReceipt}
                        className="text-[10px] font-bold text-blue-700 hover:underline flex items-center gap-0.5"
                      >
                        <Sparkles className="w-2.5 h-2.5" /> Sample Slip
                      </button>
                    </div>

                    {membershipReceiptUrl ? (
                      <div className="flex items-center gap-2 p-2 bg-emerald-50 rounded-lg border border-emerald-200">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span className="text-[11px] text-emerald-800 font-semibold truncate flex-1">
                          Slip attached
                        </span>
                        <button
                          type="button"
                          onClick={() => setMembershipReceiptUrl(null)}
                          className="text-[10px] text-rose-600 hover:underline"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <label className="cursor-pointer block text-center p-3 border border-dashed border-slate-300 rounded-lg hover:bg-slate-50 text-[11px] text-slate-500">
                        <Upload className="w-4 h-4 mx-auto mb-1 text-slate-400" />
                        <span>Upload photo or click sample slip</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            if (e.target.files && e.target.files[0]) {
                              const reader = new FileReader();
                              reader.onloadend = () => setMembershipReceiptUrl(reader.result as string);
                              reader.readAsDataURL(e.target.files[0]);
                            }
                          }}
                        />
                      </label>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2 px-3 rounded-lg text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 transition-colors shadow-sm"
                  >
                    Submit 500 ETB Verification
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tutor Profile Header Card */}
      <div className="bg-gradient-to-r from-emerald-950 via-teal-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 relative z-10">
          <img
            src={tutor.avatarUrl}
            alt="Tutor Avatar"
            className="w-20 h-20 sm:w-22 sm:h-22 rounded-2xl object-cover border-2 border-white/20 shadow-md"
          />

          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-1.5">
              <h2 className="text-2xl font-bold tracking-tight">{tutor.name}</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-200 border border-emerald-400/30">
                Ador Tutor
              </span>
              {tutor.membershipStatus === 'verified' && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500 text-white flex items-center gap-1 shadow-xs">
                  <ShieldCheck className="w-3.5 h-3.5" /> Verified Member
                </span>
              )}
            </div>
            <p className="text-xs sm:text-sm text-slate-300">
              {tutor.education} &bull; {tutor.phone} &bull; {tutor.email}
            </p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {tutor.specialties.map((spec, i) => (
                <span key={i} className="px-2.5 py-0.5 rounded-md text-xs font-medium bg-white/10 text-slate-200 border border-white/10">
                  {spec}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap border-b border-slate-200 gap-2 sm:gap-4">
        <button
          id="tutor-tab-jobs"
          onClick={() => setActiveTab('jobs')}
          className={`pb-4 px-2 sm:px-4 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === 'jobs'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          <span>Tutoring Jobs &amp; Placements</span>
          {acceptedApps.filter(a => a.commissionStatus !== 'approved').length > 0 && (
            <span className="px-2 py-0.5 text-xs rounded-full bg-emerald-600 text-white font-extrabold animate-pulse">
              Placement Action Required
            </span>
          )}
        </button>

        <button
          id="tutor-tab-report"
          onClick={() => setActiveTab('submit-report')}
          className={`pb-4 px-2 sm:px-4 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === 'submit-report'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileEdit className="w-4 h-4" />
          <span>Submit Monthly Report</span>
        </button>

        <button
          id="tutor-tab-history"
          onClick={() => setActiveTab('history')}
          className={`pb-4 px-2 sm:px-4 text-sm font-bold flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === 'history'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          <span>Submitted Reports &amp; Parent Feedback</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold">
            {myReports.length}
          </span>
        </button>
      </div>

      {/* TAB 1: TUTORING JOBS & COMMISSION FLOW */}
      {activeTab === 'jobs' && (
        <div className="space-y-8">
          
          {/* SECTION A: ACCEPTED PLACEMENTS (60% First Month vs 23% Monthly Commission Choice) */}
          {acceptedApps.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-extrabold text-sm">
                  🎉
                </span>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">
                    Congratulations! Job Placements Accepted by Admin
                  </h3>
                  <p className="text-xs text-slate-500">
                    Select your placement payment structure (Option 1 or Option 2) and submit your receipt to finalize contract.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {acceptedApps.map((app) => {
                  const job = jobs.find(j => j.id === app.jobId) || {
                    title: app.jobTitle,
                    monthlyEstimate: 12000,
                    rate: '500 ETB / hour',
                    location: 'Addis Ababa',
                  };

                  const estMonthly = job.monthlyEstimate || 10000;
                  const downpayment60 = estMonthly * 0.6;
                  const monthly23 = estMonthly * 0.23;

                  const currentChoice = selectedChoices[app.id] || app.commissionChoice || '60_percent_first_month';
                  const isVerified = app.commissionStatus === 'approved';
                  const isPendingAdmin = app.commissionStatus === 'pending_verification';

                  return (
                    <div key={app.id} className="bg-white rounded-2xl p-6 border border-emerald-200 shadow-md">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
                        <div>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 uppercase tracking-wide">
                            Placement Accepted
                          </span>
                          <h4 className="text-lg font-bold text-slate-900 mt-1">{app.jobTitle}</h4>
                          <p className="text-xs text-slate-500">
                            Est. Monthly Earnings: <strong>{estMonthly.toLocaleString()} ETB</strong> &bull; {job.rate}
                          </p>
                        </div>

                        {isVerified && (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Contract Active &amp; Verified
                          </span>
                        )}
                        {isPendingAdmin && (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300 animate-pulse">
                            <Clock className="w-4 h-4" /> Receipt Under Admin Verification
                          </span>
                        )}
                      </div>

                      {isVerified ? (
                        <div className="mt-4 p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs sm:text-sm text-emerald-900 flex items-start gap-3">
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                          <div>
                            <p className="font-bold">Contract Finalized!</p>
                            <p className="text-xs text-emerald-800 mt-0.5">
                              You selected: <strong>{app.commissionChoice === '60_percent_first_month' ? 'Option 1: 60% Downpayment' : 'Option 2: 23% Monthly Commission'}</strong>.
                              Admin has approved your receipt. You may begin tutoring according to schedule.
                            </p>
                            {app.commissionReceiptUrl && (
                              <button
                                onClick={() => onViewReceipt(app.commissionReceiptUrl!, {
                                  payerOrStudent: tutor.name,
                                  amount: app.commissionChoice === '60_percent_first_month' ? downpayment60 : monthly23,
                                  monthOrPurpose: 'Tutoring Placement Commission',
                                  status: 'Approved',
                                })}
                                className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 hover:underline mt-2"
                              >
                                <Eye className="w-3.5 h-3.5" /> View Approved Receipt
                              </button>
                            )}
                          </div>
                        </div>
                      ) : isPendingAdmin ? (
                        <div className="mt-4 p-4 bg-amber-50 rounded-xl border border-amber-200 text-xs sm:text-sm text-amber-900 flex items-start gap-3">
                          <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                          <div>
                            <p className="font-bold">Receipt Under Verification</p>
                            <p className="text-xs text-amber-800 mt-0.5">
                              Chosen Structure:{' '}
                              <strong>
                                {app.commissionChoice === '60_percent_first_month'
                                  ? `Option 1: 60% Downpayment (${downpayment60.toLocaleString()} ETB)`
                                  : `Option 2: 23% Monthly Commission (${monthly23.toLocaleString()} ETB)`}
                              </strong>
                              . Ador Executive Admin will confirm shortly.
                            </p>
                            {app.commissionReceiptUrl && (
                              <button
                                onClick={() => onViewReceipt(app.commissionReceiptUrl!, {
                                  payerOrStudent: tutor.name,
                                  amount: app.commissionChoice === '60_percent_first_month' ? downpayment60 : monthly23,
                                  method: app.commissionMethod,
                                  reference: app.commissionReference,
                                  monthOrPurpose: 'Tutoring Placement Commission',
                                  status: 'Pending Verification',
                                })}
                                className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 hover:underline mt-2"
                              >
                                <Eye className="w-3.5 h-3.5" /> View Uploaded Receipt
                              </button>
                            )}
                          </div>
                        </div>
                      ) : (
                        /* Interactive 60% vs 23% Choice Form */
                        <div className="mt-5 space-y-4">
                          <p className="text-xs font-bold uppercase tracking-wider text-slate-700">
                            Select One of the Two Payment Options for this Placement:
                          </p>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {/* Option 1: 60% Downpayment */}
                            <label
                              onClick={() => setSelectedChoices(prev => ({ ...prev, [app.id]: '60_percent_first_month' }))}
                              className={`cursor-pointer rounded-2xl p-4 border-2 transition-all block ${
                                currentChoice === '60_percent_first_month'
                                  ? 'border-emerald-600 bg-emerald-50/50 shadow-sm'
                                  : 'border-slate-200 hover:border-slate-300'
                              }`}
                            >
                              <div className="flex items-start justify-between">
                                <div className="flex items-center gap-2">
                                  <input
                                    type="radio"
                                    name={`choice-${app.id}`}
                                    checked={currentChoice === '60_percent_first_month'}
                                    onChange={() => {}}
                                    className="text-emerald-600 focus:ring-emerald-500"
                                  />
                                  <h5 className="text-sm font-bold text-slate-900">
                                    Option 1: 60% Downpayment
                                  </h5>
                                </div>
                                <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                                  One-Time
                                </span>
                              </div>
                              <p className="text-xs text-slate-600 mt-2">
                                Pay 60% of your estimated first month earnings as a single one-time placement downpayment.
                              </p>
                              <div className="mt-3 pt-2 border-t border-slate-200/70 flex items-baseline justify-between">
                                <span className="text-xs text-slate-500">Required Amount:</span>
                                <span className="text-sm font-extrabold text-slate-900">
                                  {downpayment60.toLocaleString()} ETB
                                </span>
                              </div>
                            </label>

                            {/* Option 2: 23% Monthly */}
                            <label
                              onClick={() => setSelectedChoices(prev => ({ ...prev, [app.id]: '23_percent_monthly' }))}
                              className={`cursor-pointer rounded-2xl p-4 border-2 transition-all block ${
                                currentChoice === '23_percent_monthly'
                                  ? 'border-emerald-600 bg-emerald-50/50 shadow-sm'
                                  : 'border-slate-200 hover:border-slate-300'
                              }`}
                            >
                              <div className="flex items-start justify-between">
                                <div className="flex items-center gap-2">
                                  <input
                                    type="radio"
                                    name={`choice-${app.id}`}
                                    checked={currentChoice === '23_percent_monthly'}
                                    onChange={() => {}}
                                    className="text-emerald-600 focus:ring-emerald-500"
                                  />
                                  <h5 className="text-sm font-bold text-slate-900">
                                    Option 2: 23% Monthly Commission
                                  </h5>
                                </div>
                                <span className="text-xs font-bold text-blue-800 bg-blue-100 px-2 py-0.5 rounded">
                                  Consecutive
                                </span>
                              </div>
                              <p className="text-xs text-slate-600 mt-2">
                                Pay 23% of your consecutive tutorial earnings on a recurring monthly basis.
                              </p>
                              <div className="mt-3 pt-2 border-t border-slate-200/70 flex items-baseline justify-between">
                                <span className="text-xs text-slate-500">Monthly Amount:</span>
                                <span className="text-sm font-extrabold text-slate-900">
                                  {monthly23.toLocaleString()} ETB / mo
                                </span>
                              </div>
                            </label>
                          </div>

                          {/* Bank Accounts Info reminder */}
                          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-wrap items-center justify-between gap-2">
                            <span className="text-slate-600">
                              <strong>Transfer to Ador:</strong> Telebirr: <code>0911 22 33 44</code> | CBE: <code>1000 2938 49182</code>
                            </span>
                            <button
                              type="button"
                              onClick={() => handleGenerateCommissionReceipt(
                                app.id,
                                currentChoice === '60_percent_first_month' ? downpayment60 : monthly23
                              )}
                              className="text-xs font-bold text-blue-700 hover:underline flex items-center gap-1"
                            >
                              <Sparkles className="w-3.5 h-3.5" /> Auto-generate Sample Slip
                            </button>
                          </div>

                          {/* Inputs & Screenshot */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                            <div>
                              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                                Payment Method *
                              </label>
                              <select
                                value={commissionMethods[app.id] || 'Telebirr'}
                                onChange={(e) => setCommissionMethods(prev => ({ ...prev, [app.id]: e.target.value }))}
                                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-emerald-600"
                              >
                                <option value="Telebirr">Telebirr (0911 22 33 44)</option>
                                <option value="Commercial Bank of Ethiopia (CBE)">CBE (1000 2938 49182)</option>
                                <option value="Awash Bank">Awash Bank</option>
                              </select>
                            </div>

                            <div>
                              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                                Transaction Reference
                              </label>
                              <input
                                type="text"
                                value={commissionRefs[app.id] || ''}
                                onChange={(e) => setCommissionRefs(prev => ({ ...prev, [app.id]: e.target.value }))}
                                placeholder="e.g. TXN98765"
                                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600"
                              />
                            </div>
                          </div>

                          {/* Receipt Screenshot Status */}
                          {commissionReceipts[app.id] && (
                            <div className="flex items-center gap-2 p-2 bg-emerald-50 rounded-xl border border-emerald-200">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                              <span className="text-xs font-semibold text-emerald-800 flex-1">
                                Payment Receipt Attached
                              </span>
                              <button
                                type="button"
                                onClick={() => setCommissionReceipts(prev => ({ ...prev, [app.id]: '' }))}
                                className="text-xs text-rose-600 hover:underline"
                              >
                                Clear
                              </button>
                            </div>
                          )}

                          <button
                            type="button"
                            onClick={() => handleCommissionSubmit(app.id, estMonthly)}
                            className="w-full py-2.5 px-4 rounded-xl text-sm font-bold text-white bg-emerald-700 hover:bg-emerald-800 transition-colors shadow-sm"
                          >
                            Submit Commission Receipt Screenshot
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* SECTION B: AVAILABLE TUTORING JOBS BOARD */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Available Tutoring Jobs</h3>
                <p className="text-xs text-slate-500">
                  Apply for matching tutorial placements across Addis Ababa &amp; online.
                </p>
              </div>

              {/* Search & Filters */}
              <div className="flex flex-wrap items-center gap-2.5">
                <div className="relative w-full sm:w-60">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search title, subject, location..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  />
                </div>

                <select
                  value={filterSubject}
                  onChange={(e) => setFilterSubject(e.target.value)}
                  className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 bg-white text-slate-700 focus:outline-none"
                >
                  <option value="all">All Subjects</option>
                  <option value="physics">Physics</option>
                  <option value="math">Mathematics</option>
                  <option value="science">General Science</option>
                  <option value="cambridge">Cambridge IGCSE</option>
                </select>
              </div>
            </div>

            {/* Jobs List Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredJobs.map((job) => {
                const application = myApplications.find(a => a.jobId === job.id);
                const hasApplied = !!application;
                const isApproved = application?.status === 'approved';

                return (
                  <div
                    key={job.id}
                    className="bg-slate-50/50 hover:bg-slate-50 rounded-2xl p-5 border border-slate-200 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">
                          {job.grade}
                        </span>
                        <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                          {job.rate}
                        </span>
                      </div>

                      <h4 className="text-base font-bold text-slate-900 leading-snug mb-2">
                        {job.title}
                      </h4>

                      <div className="space-y-1.5 text-xs text-slate-600 mb-3">
                        <p className="flex items-center gap-1.5">
                          <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                          <span><strong>Subject:</strong> {job.subject}</span>
                        </p>
                        <p className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-rose-500" />
                          <span><strong>Location:</strong> {job.location}</span>
                        </p>
                        <p className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span><strong>Schedule:</strong> {job.schedule}</span>
                        </p>
                      </div>

                      <p className="text-xs text-slate-500 leading-relaxed line-clamp-2 mb-4">
                        {job.description}
                      </p>
                    </div>

                    <div>
                      {hasApplied ? (
                        <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-600">Application Status:</span>
                          {isApproved ? (
                            <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Accepted! See placement above
                            </span>
                          ) : (
                            <span className="text-xs font-bold text-amber-700 flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5" /> Under Admin Review
                            </span>
                          )}
                        </div>
                      ) : (
                        <button
                          onClick={() => handleApplyClick(job)}
                          className="w-full py-2 px-3 rounded-xl text-xs font-bold text-emerald-800 bg-emerald-100/80 hover:bg-emerald-200/90 border border-emerald-300 transition-colors flex items-center justify-center gap-1.5"
                        >
                          <span>⚡ 1-Click Apply with My Profile</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: SUBMIT MONTHLY REPORT */}
      {activeTab === 'submit-report' && (
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm max-w-3xl mx-auto">
          <div className="mb-6">
            <h3 className="text-xl font-bold text-slate-900">Submit Student Monthly Academic Report</h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Fill out your student evaluation for the completed month. Ador Administration will review and publish it directly to the parent for approval.
            </p>
          </div>

          <form onSubmit={handleReportSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Student Full Name *
                </label>
                <input
                  type="text"
                  value={reportStudentName}
                  onChange={(e) => setReportStudentName(e.target.value)}
                  required
                  placeholder="e.g. Samuel Kassahun"
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Parent Email *
                </label>
                <input
                  type="email"
                  value={reportParentEmail}
                  onChange={(e) => setReportParentEmail(e.target.value)}
                  required
                  placeholder="e.g. almaz.m@gmail.com"
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Evaluation Month *
                </label>
                <select
                  value={reportMonth}
                  onChange={(e) => setReportMonth(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                >
                  <option value="First Month (Meskerem / Month 1)">First Month (Meskerem / Month 1)</option>
                  <option value="Second Month (Tikimt / Month 2)">Second Month (Tikimt / Month 2)</option>
                  <option value="Third Month (Hidar / Month 3)">Third Month (Hidar / Month 3)</option>
                  <option value="Fourth Month (Tahsas / Month 4)">Fourth Month (Tahsas / Month 4)</option>
                  <option value="Fifth Month (Tir / Month 5)">Fifth Month (Tir / Month 5)</option>
                  <option value="Sixth Month (Yekatit / Month 6)">Sixth Month (Yekatit / Month 6)</option>
                  <option value="Seventh Month (Megabit / Month 7)">Seventh Month (Megabit / Month 7)</option>
                  <option value="Eighth Month (Miyazya / Month 8)">Eighth Month (Miyazya / Month 8)</option>
                  <option value="Ninth Month (Ginbot / Month 9)">Ninth Month (Ginbot / Month 9)</option>
                  <option value="Tenth Month (Sene / Month 10)">Tenth Month (Sene / Month 10)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Total Hours Completed *
                </label>
                <input
                  type="number"
                  value={reportHours}
                  onChange={(e) => setReportHours(e.target.value)}
                  required
                  min="1"
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Overall Academic Performance Rating *
              </label>
              <select
                value={reportScore}
                onChange={(e) => setReportScore(e.target.value as any)}
                className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-emerald-600 focus:outline-none"
              >
                <option value="Excellent (Straight A / 90%+)">Excellent (Straight A / 90%+)</option>
                <option value="Very Good (B+ to A / 80-89%)">Very Good (B+ to A / 80-89%)</option>
                <option value="Good - Steady Improvement (70-79%)">Good - Steady Improvement (70-79%)</option>
                <option value="Needs More Attention / Practice (<70%)">Needs More Attention / Practice (&lt;70%)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Topics Covered &amp; Student Strengths *
              </label>
              <textarea
                value={reportStrengths}
                onChange={(e) => setReportStrengths(e.target.value)}
                required
                rows={3}
                placeholder="Detail curriculum units covered, tests completed, and areas where the student demonstrated mastery..."
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Areas Needing Improvement &amp; Action Plan *
              </label>
              <textarea
                value={reportImprovements}
                onChange={(e) => setReportImprovements(e.target.value)}
                required
                rows={3}
                placeholder="Specify focus areas for the upcoming month, homework guidelines, and exam preparation advice..."
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmittingReport}
              className="w-full py-3 px-4 rounded-xl text-sm font-bold text-white bg-emerald-700 hover:bg-emerald-800 transition-colors shadow-md shadow-emerald-700/20 disabled:opacity-50"
            >
              {isSubmittingReport ? 'Submitting Report...' : 'Submit Monthly Report to Admin'}
            </button>
          </form>
        </div>
      )}

      {/* TAB 3: SUBMITTED REPORTS & PARENT FEEDBACK */}
      {activeTab === 'history' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Your Submitted Monthly Reports &amp; Parent Decisions</h3>
              <p className="text-xs text-slate-500">Live tracker of Admin verification and Parent acceptance.</p>
            </div>
            <button
              onClick={() => setActiveTab('submit-report')}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 transition-colors shadow-xs"
            >
              + Submit New Report
            </button>
          </div>

          {myReports.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <ClipboardList className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm font-medium text-slate-600">You have not submitted any reports yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold text-xs uppercase tracking-wider">
                    <th className="pb-3 pr-2">Month</th>
                    <th className="pb-3 px-2">Student</th>
                    <th className="pb-3 px-2">Hours</th>
                    <th className="pb-3 px-2">Admin Status</th>
                    <th className="pb-3 pl-2 text-right">Parent Decision</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {myReports.map((r) => {
                    const isDispatched = r.status === 'approved_for_parent';
                    const isAccepted = r.parentDecision === 'accepted';
                    const isDeclined = r.parentDecision === 'declined';
                    const isPendingParent = r.parentDecision === 'pending';

                    return (
                      <tr key={r.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3.5 pr-2 font-bold text-slate-800">
                          {r.month}
                        </td>
                        <td className="py-3.5 px-2 font-medium text-slate-700">
                          {r.studentName}
                        </td>
                        <td className="py-3.5 px-2 text-slate-600 font-semibold">
                          {r.totalHours} hrs
                        </td>
                        <td className="py-3.5 px-2">
                          {isDispatched ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200">
                              Dispatched to Parent
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200">
                              Under Admin Review
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 pl-2 text-right">
                          {isAccepted && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Accepted by Parent
                            </span>
                          )}
                          {isDeclined && (
                            <div className="text-right">
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                                <XCircle className="w-3.5 h-3.5" /> Declined by Parent
                              </span>
                              {r.parentFeedback && (
                                <p className="text-[11px] text-rose-600 mt-1 italic">
                                  "{r.parentFeedback}"
                                </p>
                              )}
                            </div>
                          )}
                          {isPendingParent && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                              <Clock className="w-3.5 h-3.5" /> Awaiting Parent
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

    </div>
  );
};

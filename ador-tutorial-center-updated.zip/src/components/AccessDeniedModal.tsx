import React from 'react';
import { CurrentUser, ActiveView } from '../types';
import { TranslationDictionary } from '../data/translations';

interface AccessDeniedModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: CurrentUser;
  attemptedView: ActiveView;
  onSwitchAccount: () => void;
  onNavigateSafe: (view: ActiveView) => void;
  t: TranslationDictionary;
}

export const AccessDeniedModal: React.FC<AccessDeniedModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  attemptedView,
  onSwitchAccount,
  onNavigateSafe,
  t,
}) => {
  if (!isOpen) return null;

  const getDestinationName = (view: ActiveView) => {
    switch (view) {
      case 'parent': return 'Parent & Student Portal';
      case 'tutor': return 'Tutor Workspace & Job Dispatch';
      case 'admin': return 'Executive Administrator Cockpit';
      default: return 'Restricted Portal';
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'tutor': return { text: 'Tutor Account', color: 'bg-emerald-100 text-emerald-800 border-emerald-300' };
      case 'parent': return { text: 'Parent Account', color: 'bg-blue-100 text-blue-800 border-blue-300' };
      case 'admin': return { text: 'Administrator Account', color: 'bg-indigo-100 text-indigo-800 border-indigo-300' };
      default: return { text: 'Guest Visitor', color: 'bg-slate-100 text-slate-800 border-slate-300' };
    }
  };

  const badge = getRoleBadge(currentUser.role);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-rose-200 overflow-hidden">
        
        {/* Security Warning Header */}
        <div className="bg-gradient-to-r from-rose-900 via-rose-800 to-amber-950 text-white p-6 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white px-2 py-0.5 rounded-lg hover:bg-white/10 transition-colors text-xs font-bold"
          >
            ✕
          </button>

          <span className="px-2.5 py-0.5 rounded-full bg-rose-400/20 text-rose-200 text-[10px] font-bold uppercase tracking-wider border border-rose-400/30">
            Role-Based Access Control (RBAC)
          </span>

          <h2 className="text-xl font-black tracking-tight mt-2">
            Access Denied: Role Mismatch
          </h2>
          <p className="text-xs text-rose-100/80 mt-1">
            Separation of Parent, Tutor &amp; Administrator Environments
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4">
          
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">Currently Authenticated:</span>
              <span className={`px-2 py-0.5 rounded-md font-bold text-[11px] border ${badge.color}`}>
                {badge.text}
              </span>
            </div>
            <p className="font-bold text-slate-800">{currentUser.name} ({currentUser.email})</p>

            <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
              <span className="text-slate-500 font-medium">Target Destination:</span>
              <span className="font-bold text-rose-700">{getDestinationName(attemptedView)}</span>
            </div>
          </div>

          <div className="text-xs text-slate-600 leading-relaxed space-y-2">
            <p>
              Under Ador Tutorial Center security policy:
            </p>
            <ul className="list-disc list-inside space-y-1 text-slate-700 font-medium">
              <li><strong>Tutors cannot access</strong> the Parent Portal or Admin Hub to safeguard parent billing, student progress files, and administrative controls.</li>
              <li><strong>Parents cannot access</strong> the Tutor operational dashboard or Admin Hub to preserve tutor applicant data and scoring.</li>
              <li><strong>Administrative tools</strong> are strictly guarded and require verified director credentials.</li>
            </ul>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 space-y-2">
            <button
              onClick={() => {
                onClose();
                onSwitchAccount();
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-xs transition-colors"
            >
              Switch / Sign In as Authorized {attemptedView === 'parent' ? 'Parent' : attemptedView === 'tutor' ? 'Tutor' : 'Admin'}
            </button>

            {currentUser.role !== 'guest' && (
              <button
                onClick={() => {
                  onClose();
                  onNavigateSafe(currentUser.role as ActiveView);
                }}
                className="w-full py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs transition-colors"
              >
                Return to My Authorized Dashboard ({currentUser.role.toUpperCase()})
              </button>
            )}

            <button
              onClick={() => {
                onClose();
                onNavigateSafe('website');
              }}
              className="w-full py-2 text-center text-xs text-slate-500 hover:text-slate-800 transition-colors"
            >
              Return to Official Website Home
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};

<?php
/**
 * Plugin Name: Ador Tutorial Center Portal & Management Platform
 * Plugin URI: https://adortutorial.et
 * Description: Complete multi-role tutoring portal, parent tuition verification desk, tutor recruitment platform, monthly academic progress reports, and bilingual English/Amharic interface for Ador Tutorial Center.
 * Version: 1.0.0
 * Author: Ador Tutorial Center & Eyerusalem Melaku
 * Author URI: https://adortutorial.et
 * License: GPL2
 * Text Domain: ador-tutorial-center
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shortcode: [ador_tutorial_center]
 * Optional attributes: height="950px" width="100%"
 */
function ador_tutorial_center_shortcode($atts) {
    $a = shortcode_atts(array(
        'height' => '950px',
        'width' => '100%',
        'border_radius' => '16px',
    ), $atts);

    $plugin_url = plugin_dir_url(__FILE__);
    $app_url = $plugin_url . 'app/index.html';

    $output = '<div class="ador-tutorial-center-wrapper" style="width:' . esc_attr($a['width']) . '; max-width: 100%; margin: 1.5rem auto; clear: both;">';
    $output .= '  <div style="position: relative; width: 100%; height:' . esc_attr($a['height']) . '; border-radius:' . esc_attr($a['border_radius']) . '; overflow: hidden; box-shadow: 0 10px 30px rgba(0, 51, 153, 0.12); border: 1px solid #cbd5e1; background: #ffffff;">';
    $output .= '    <iframe src="' . esc_url($app_url) . '" title="Ador Tutorial Center" style="width: 100%; height: 100%; border: none; min-height: 650px;" allow="clipboard-read; clipboard-write; fullscreen"></iframe>';
    $output .= '  </div>';
    $output .= '</div>';

    return $output;
}
add_shortcode('ador_tutorial_center', 'ador_tutorial_center_shortcode');

/**
 * Admin Menu Page
 */
function ador_tutorial_center_admin_menu() {
    add_menu_page(
        'Ador Tutorial Center',
        'Ador Center',
        'manage_options',
        'ador-tutorial-center',
        'ador_tutorial_center_admin_page',
        'dashicons-welcome-learn-more',
        30
    );
}
add_action('admin_menu', 'ador_tutorial_center_admin_menu');

function ador_tutorial_center_admin_page() {
    $plugin_url = plugin_dir_url(__FILE__);
    $app_url = $plugin_url . 'app/index.html';
    ?>
    <div class="wrap" style="margin-right: 20px;">
        <h1 style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px; font-weight: 800; color: #1e3a8a;">
            <span>Ador Tutorial Center &bull; Executive Operations Portal</span>
        </h1>
        <p style="color: #475569; font-size: 14px; margin-bottom: 16px;">
            To embed the tutorial center onto any public page, post, or Elementor container, insert this shortcode: <code style="font-size: 14px; background: #e0e7ff; color: #1e40af; padding: 3px 8px; border-radius: 4px; font-weight: bold;">[ador_tutorial_center]</code>
        </p>
        <div style="width: 100%; height: 86vh; background: #fff; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.06); border: 1px solid #cbd5e1;">
            <iframe src="<?php echo esc_url($app_url); ?>" style="width: 100%; height: 100%; border: none;" allow="clipboard-read; clipboard-write; fullscreen"></iframe>
        </div>
    </div>
    <?php
}

=== Ador Tutorial Center Portal ===
Contributors: Eyerusalem Melaku, Ador Tutorial Center
Tags: tutoring, education, ethiopia, amharic, student management, payment verification
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.0.0
License: GPLv2 or later

== Description ==
Complete tutorial center management platform for Ador Tutorial Center (Addis Ababa, Ethiopia).
Features bilingual English/Amharic UI, Parent tuition desk, Tutor 500 ETB membership verification, monthly progress reports, salary payouts, and role-based access control.

== Quick Start ==
1. Go to WP Admin > Plugins > Add New > Upload Plugin.
2. Choose ador-tutorial-center-wp-plugin.zip and click Install Now.
3. Activate the plugin.
4. Add [ador_tutorial_center] to any page or post.

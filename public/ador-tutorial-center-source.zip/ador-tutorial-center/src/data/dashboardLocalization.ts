import { SupportedLanguage } from '../types';

// Map known Ethiopian & International names into each supported language script/orthography
export const LOCALIZED_PERSON_NAMES: Record<string, Partial<Record<SupportedLanguage, string>>> = {
  'Almaz Mengistu': {
    en: 'Almaz Mengistu',
    am: 'አልማዝ መንግስቱ',
    om: 'Almaz Mangistuu',
    ti: 'ኣልማዝ መንግስቱ',
    so: 'Almaz Mengistu',
    ar: 'ألماز منغستو',
    fr: 'Almaz Mengistu',
    es: 'Almaz Mengistu',
    de: 'Almaz Mengistu',
    zh: '阿尔马兹·门吉斯图',
    sw: 'Almaz Mengistu',
  },
  'Dawit Yohannes': {
    en: 'Dawit Yohannes',
    am: 'ዳዊት ዮሐንስ',
    om: 'Daawit Yohaannis',
    ti: 'ዳዊት ዮሃንስ',
    so: 'Dawit Yohannes',
    ar: 'داويت يوهانس',
    fr: 'Dawit Yohannes',
    es: 'Dawit Yohannes',
    de: 'Dawit Yohannes',
    zh: '达维特·约翰内斯',
    sw: 'Dawit Yohannes',
  },
  'Samuel Kassahun': {
    en: 'Samuel Kassahun',
    am: 'ሳሙኤል ካሳሁን',
    om: 'Saamu\'eel Kaasaahuun',
    ti: 'ሳሙኤል ካሳሁን',
    so: 'Samuel Kassahun',
    ar: 'صامويل كاساهون',
    fr: 'Samuel Kassahun',
    es: 'Samuel Kassahun',
    de: 'Samuel Kassahun',
    zh: '塞缪尔·卡萨洪',
    sw: 'Samuel Kassahun',
  },
  'Liya Daniel': {
    en: 'Liya Daniel',
    am: 'ሊያ ዳንኤል',
    om: 'Liyaa Daani\'eel',
    ti: 'ሊያ ዳንኤል',
    so: 'Liya Daniel',
    ar: 'ليا دانيال',
    fr: 'Liya Daniel',
    es: 'Liya Daniel',
    de: 'Liya Daniel',
    zh: '莉亚·丹尼尔',
    sw: 'Liya Daniel',
  },
  'Yafet Dawit': {
    en: 'Yafet Dawit',
    am: 'ያፌት ዳዊት',
    om: 'Yafeet Daawit',
    ti: 'ያፌት ዳዊት',
    so: 'Yafet Dawit',
    ar: 'يافيت داويت',
    fr: 'Yafet Dawit',
    es: 'Yafet Dawit',
    de: 'Yafet Dawit',
    zh: '亚菲特·达维特',
    sw: 'Yafet Dawit',
  },
  'Kassahun Bekele': {
    en: 'Kassahun Bekele',
    am: 'ካሳሁን በቀለ',
    om: 'Kaasaahuun Baqqalaa',
    ti: 'ካሳሁን በቀለ',
    so: 'Kassahun Bekele',
    ar: 'كاساهون بيكيلي',
    fr: 'Kassahun Bekele',
    es: 'Kassahun Bekele',
    de: 'Kassahun Bekele',
    zh: '卡萨洪·贝克勒',
    sw: 'Kassahun Bekele',
  },
  'Bethlehem Tadesse': {
    en: 'Bethlehem Tadesse',
    am: 'ቤተልሔም ታደሰ',
    om: 'Beeteliheem Taaddasaa',
    ti: 'ቤተልሄም ታደሰ',
    so: 'Bethlehem Tadesse',
    ar: 'بيت لحم تاديسي',
    fr: 'Bethlehem Tadesse',
    es: 'Bethlehem Tadesse',
    de: 'Bethlehem Tadesse',
    zh: '伯利恒·塔德塞',
    sw: 'Bethlehem Tadesse',
  },
  'Abebe Kebede': {
    en: 'Abebe Kebede',
    am: 'አበበ ከበደ',
    om: 'Abebe Kabbadaa',
    ti: 'ኣበበ ከበደ',
    so: 'Abebe Kebede',
    ar: 'أبيبي كيبيدي',
    fr: 'Abebe Kebede',
    es: 'Abebe Kebede',
    de: 'Abebe Kebede',
    zh: '阿贝贝·凯贝德',
    sw: 'Abebe Kebede',
  },
  'Abebe Kebede (MSc)': {
    en: 'Abebe Kebede (MSc)',
    am: 'አበበ ከበደ (ኤምኤስሲ)',
    om: 'Abebe Kabbadaa (MSc)',
    ti: 'ኣበበ ከበደ (ኤምኤስሲ)',
    so: 'Abebe Kebede (MSc)',
    ar: 'أبيبي كيبيدي (ماجستير)',
    fr: 'Abebe Kebede (MSc)',
    es: 'Abebe Kebede (MSc)',
    de: 'Abebe Kebede (MSc)',
    zh: '阿贝贝·凯贝德 (理学硕士)',
    sw: 'Abebe Kebede (MSc)',
  },
  'Dr. Elias Solomon': {
    en: 'Dr. Elias Solomon',
    am: 'ዶ/ር ኤልያስ ሰለሞን',
    om: 'Dr. Eeliyaas Solomoon',
    ti: 'ዶ/ር ኤልያስ ሰለሞን',
    so: 'Dr. Elias Solomon',
    ar: 'د. إلياس سليمان',
    fr: 'Dr. Elias Solomon',
    es: 'Dr. Elias Solomon',
    de: 'Dr. Elias Solomon',
    zh: '埃利亚斯·所罗门 博士',
    sw: 'Dkt. Elias Solomon',
  },
  'Aster Tesfaye': {
    en: 'Woizero Aster Tesfaye',
    am: 'ወ/ሮ አስቴር ተስፋዬ',
    om: 'Aadde Asteer Tasfaayee',
    ti: 'ወ/ሮ ኣስቴር ተስፋየ',
    so: 'Marwo Aster Tesfaye',
    ar: 'السيدة أستير تسفاي',
    fr: 'Mme Aster Tesfaye',
    es: 'Sra. Aster Tesfaye',
    de: 'Frau Aster Tesfaye',
    zh: '阿斯特·特斯法耶 夫人',
    sw: 'Bi. Aster Tesfaye',
  },
  'Eyerusalem Melaku': {
    en: 'Eyerusalem Melaku',
    am: 'እየሩሳሌም መላኩ',
    om: 'Iyyarusaalem Mallaakuu',
    ti: 'እየሩሳሌም መላኩ',
    so: 'Eyerusalem Melaku',
    ar: 'أورشليم ميلاكو',
    fr: 'Eyerusalem Melaku',
    es: 'Eyerusalem Melaku',
    de: 'Eyerusalem Melaku',
    zh: '耶路撒冷·梅拉库',
    sw: 'Eyerusalem Melaku',
  },
  'Eyerusalem Melaku (Director)': {
    en: 'Eyerusalem Melaku (Director)',
    am: 'እየሩሳሌም መላኩ (ዋና ዳይሬክተር)',
    om: 'Iyyarusaalem Mallaakuu (Daarektara)',
    ti: 'እየሩሳሌም መላኩ (ዋና ዳይሬክተር)',
    so: 'Eyerusalem Melaku (Agaasime)',
    ar: 'أورشليم ميلاكو (المديرة العامة)',
    fr: 'Eyerusalem Melaku (Directrice)',
    es: 'Eyerusalem Melaku (Directora)',
    de: 'Eyerusalem Melaku (Direktorin)',
    zh: '耶路撒冷·梅拉库 (总监)',
    sw: 'Eyerusalem Melaku (Mkurugenzi)',
  }
};

export function getLocalizedPersonName(name: string | undefined, lang: SupportedLanguage | string = 'en'): string {
  if (!name) return '';
  const clean = name.trim();
  const found = LOCALIZED_PERSON_NAMES[clean];
  if (found && (found as any)[lang]) {
    return (found as any)[lang];
  }
  // Try sub-match (e.g. if name contains '(Almaz)')
  for (const [key, mapping] of Object.entries(LOCALIZED_PERSON_NAMES)) {
    if (clean.includes(key)) {
      const translatedPart = (mapping as any)[lang] || key;
      return clean.replace(key, translatedPart);
    }
  }
  return name;
}

// Localize Month & Payment periods
export const LOCALIZED_MONTHS: Record<string, Partial<Record<SupportedLanguage, string>>> = {
  'First Month (Meskerem / Month 1)': {
    en: 'First Month (Meskerem / Month 1)',
    am: 'የመጀመሪያ ወር (መስከረም / ወር 1)',
    om: 'Ji’a Tokkoffaa (Fulbaana / Ji’a 1)',
    ti: 'ቀዳማይ ወርሒ (መስከረም / ወርሒ 1)',
    so: 'Bisha Koowaad (Meskerem)',
    ar: 'الشهر الأول (مسكريم / الشهر 1)',
    fr: 'Premier Mois (Meskerem / Mois 1)',
    es: 'Primer Mes (Meskerem / Mes 1)',
    de: 'Erster Monat (Meskerem / Monat 1)',
    zh: '第一个月 (梅斯克雷姆 / 第1月)',
    sw: 'Mwezi wa Kwanza (Meskerem)',
  },
  'Second Month (Tikimt / Month 2)': {
    en: 'Second Month (Tikimt / Month 2)',
    am: 'ሁለተኛ ወር (ጥቅምት / ወር 2)',
    om: 'Ji’a Lammaffaa (Onkololeessa / Ji’a 2)',
    ti: 'ካልኣይ ወርሒ (ጥቅምቲ / ወርሒ 2)',
    so: 'Bisha Labaad (Tikimt)',
    ar: 'الشهر الثاني (طقمت / الشهر 2)',
    fr: 'Deuxième Mois (Tikimt / Mois 2)',
    es: 'Segundo Mes (Tikimt / Mes 2)',
    de: 'Zweiter Monat (Tikimt / Monat 2)',
    zh: '第二个月 (蒂克姆特 / 第2月)',
    sw: 'Mwezi wa Pili (Tikimt)',
  },
  'Registration Fee': {
    en: 'Registration Fee',
    am: 'የምዝገባ ክፍያ',
    om: 'Kaffaltii Galmee',
    ti: 'ክፍሊት ምዝገባ',
    so: 'Lacagta Diiwaangelinta',
    ar: 'رسوم التسجيل',
    fr: 'Frais d\'inscription',
    es: 'Tarifa de Registro',
    de: 'Anmeldegebühr',
    zh: '注册费',
    sw: 'Ada ya Usajili',
  },
  'Tutor 500 ETB Membership': {
    en: 'Tutor 500 ETB Membership Fee',
    am: 'የመምህራን 500 ብር የአባልነት ክፍያ',
    om: 'Kaffaltii Miseensummaa Barsiisotaa 500 ETB',
    ti: 'ናይ መማህራን 500 ቅርሺ ክፍሊት ኣባልነት',
    so: 'Lacagta Xubinnimada Macallinka ee 500 ETB',
    ar: 'رسوم عضوية المعلم 500 بر',
    fr: 'Frais d\'adhésion tuteur 500 ETB',
    es: 'Cuota de Membresía de Tutor 500 ETB',
    de: 'Tutor-Mitgliedsbeitrag 500 ETB',
    zh: '教师500比尔会员认证费',
    sw: 'Ada ya Uanachama wa Mkufunzi 500 ETB',
  }
};

export function getLocalizedMonth(month: string | undefined, lang: SupportedLanguage | string = 'en'): string {
  if (!month) return '';
  const clean = month.trim();
  const found = LOCALIZED_MONTHS[clean];
  if (found && (found as any)[lang]) {
    return (found as any)[lang];
  }
  return month;
}

// Localize Progress Scores in reports
export const LOCALIZED_SCORES: Record<string, Partial<Record<SupportedLanguage, string>>> = {
  'Very Good (B+ to A / 80-89%)': {
    en: 'Very Good (B+ to A / 80-89%)',
    am: 'በጣም ጥሩ (B+ እስከ A / 80-89%)',
    om: 'Baay\'ee Gaarii (B+ hanga A / 80-89%)',
    ti: 'ኣዝዩ ፅቡቕ (B+ ክሳብ A / 80-89%)',
    so: 'Aad u Wanaagsan (B+ ilaa A)',
    ar: 'جيد جداً (B+ إلى A / 80-89%)',
    fr: 'Très Bien (B+ à A / 80-89%)',
    es: 'Muy Bueno (B+ a A / 80-89%)',
    de: 'Sehr Gut (B+ bis A / 80-89%)',
    zh: '非常好 (B+ 至 A / 80-89%)',
    sw: 'Nzuri Sana (B+ hadi A / 80-89%)',
  },
  'Excellent (Straight A / 90%+)': {
    en: 'Excellent (Straight A / 90%+)',
    am: 'እጅግ በጣም ጥሩ (ቀጥታ A / 90%+)',
    om: 'Olaanaa (A Qulqulluu / 90%+)',
    ti: 'ብሉጽ (ቀጥታ A / 90%+)',
    so: 'Heersare (A / 90%+)',
    ar: 'ممتاز (امتياز A / 90%+)',
    fr: 'Excellent (A / 90%+)',
    es: 'Excelente (A / 90%+)',
    de: 'Ausgezeichnet (A / 90%+)',
    zh: '优秀 (全优 A / 90%+)',
    sw: 'Bora Kabisa (A / 90%+)',
  }
};

export function getLocalizedScore(score: string | undefined, lang: SupportedLanguage | string = 'en'): string {
  if (!score) return '';
  const clean = score.trim();
  const found = LOCALIZED_SCORES[clean];
  if (found && (found as any)[lang]) {
    return (found as any)[lang];
  }
  return score;
}

// Localize Action Buttons & Table Headers
export const LOCALIZED_ACTIONS: Record<string, Partial<Record<SupportedLanguage, string>>> = {
  approve: {
    en: 'Approve',
    am: 'አጽድቅ',
    om: 'Mirkaneessi',
    ti: 'ኣጽድቕ',
    so: 'Oggolow',
    ar: 'اعتماد',
    fr: 'Approuver',
    es: 'Aprobar',
    de: 'Genehmigen',
    zh: '批准',
    sw: 'Idhinisha',
  },
  reject: {
    en: 'Reject',
    am: 'ውድቅ አድርግ',
    om: 'Kufisi',
    ti: 'ንጸጎ',
    so: 'Diid',
    ar: 'رفض',
    fr: 'Rejeter',
    es: 'Rechazar',
    de: 'Ablehnen',
    zh: '拒绝',
    sw: 'Kataa',
  },
  viewReceipt: {
    en: 'View Receipt',
    am: 'ደረሰኝ እይ',
    om: 'Nagahee Ilaali',
    ti: 'ቅብሊት ርአ',
    so: 'Fiiri Rasiidka',
    ar: 'عرض الإيصال',
    fr: 'Voir le reçu',
    es: 'Ver Recibo',
    de: 'Beleg ansehen',
    zh: '查看收据',
    sw: 'Tazama Risiti',
  },
  readFullReport: {
    en: 'Read Full Report',
    am: 'ሙሉውን ሪፖርት አንብብ',
    om: 'Gabaasa Guutuu Dubbisi',
    ti: 'ምሉእ ጸብጻብ ኣንብብ',
    so: 'Akhri Warbixinta Buuxda',
    ar: 'قراءة التقرير بالكامل',
    fr: 'Lire le rapport complet',
    es: 'Leer Informe Completo',
    de: 'Vollständigen Bericht lesen',
    zh: '阅读完整报告',
    sw: 'Soma Ripoti Kamili',
  },
  collapseView: {
    en: 'Collapse View',
    am: 'እይታን አሳንስ',
    om: 'Gabaabsi',
    ti: 'ኣሕጽር',
    so: 'Soo Koob',
    ar: 'طي العرض',
    fr: 'Réduire',
    es: 'Contraer',
    de: 'Einklappen',
    zh: '折叠视图',
    sw: 'Kunja',
  },
  openInDialog: {
    en: 'Open in Dialog',
    am: 'በመስኮት ክፈት',
    om: 'Foddaadhaan Bani',
    ti: 'ብመስኮት ክፈት',
    so: 'Ku Fur Daaqad',
    ar: 'فتح في نافذة',
    fr: 'Ouvrir en fenêtre',
    es: 'Abrir en Ventana',
    de: 'Im Dialog öffnen',
    zh: '在弹窗中打开',
    sw: 'Fungua Dirishani',
  },
  approveForParent: {
    en: 'Approve & Dispatch to Parent',
    am: 'አጽድቅና ለወላጅ ላክ',
    om: 'Mirkaneessii Warratti Ergi',
    ti: 'ኣጽዲቕካ ናብ ወለዲ ላእኽ',
    so: 'Oggolow oo u dir Waalidka',
    ar: 'اعتماد وإرسال إلى ولي الأمر',
    fr: 'Approuver et envoyer au parent',
    es: 'Aprobar y Enviar al Padre',
    de: 'Genehmigen und an Eltern senden',
    zh: '批准并发送给家长',
    sw: 'Idhinisha na Utume kwa Mzazi',
  },
  close: {
    en: 'Close',
    am: 'ዝጋ',
    om: 'Cufi',
    ti: 'ዕጸው',
    so: 'Xidh',
    ar: 'إغلاق',
    fr: 'Fermer',
    es: 'Cerrar',
    de: 'Schließen',
    zh: '关闭',
    sw: 'Funga',
  },
  statusApproved: {
    en: 'Verified & Approved',
    am: 'የተረጋገጠ እና የጸደቀ',
    om: 'Mirkanaa\'ee Fudhatama Argate',
    ti: 'ዝተረጋገጸን ዝተጸደቐን',
    so: 'La Xaqiijiyay & La Oggolaaday',
    ar: 'تم التحقق والاعتماد',
    fr: 'Vérifié et approuvé',
    es: 'Verificado y Aprobado',
    de: 'Verifiziert und genehmigt',
    zh: '已验证并批准',
    sw: 'Imethibitishwa na Kuidhinishwa',
  },
  statusPending: {
    en: 'Pending Verification',
    am: 'በማረጋገጥ ላይ ያለ',
    om: 'Adeemsa Mirkaneessaa Irra Jira',
    ti: 'ኣብ ምርግጋጽ ዘሎ',
    so: 'Sugaya Xaqiijin',
    ar: 'قيد التحقق',
    fr: 'En attente de vérification',
    es: 'Pendiente de Verificación',
    de: 'Ausstehende Verifizierung',
    zh: '待验证',
    sw: 'Inasubiri Uthibitisho',
  }
};

export function getLocalizedActionText(actionKey: string, lang: SupportedLanguage | string = 'en'): string {
  const found = LOCALIZED_ACTIONS[actionKey];
  if (found && (found as any)[lang]) {
    return (found as any)[lang];
  }
  return actionKey;
}

// Localized Tutor Education Strings
export function getLocalizedTutorEducation(lang: SupportedLanguage | string = 'en'): string {
  switch (lang) {
    case 'am':
      return 'የሂሳብ ትምህርት ሁለተኛ ዲግሪ (አአዩ) • የ5+ ዓመታት የማስተማር ልምድ';
    case 'om':
      return 'Digrii Lammaffaa Herregaan (Yuunivarsiitii Finfinnee) • Muuxannoo Barsiisummaa Waggaa 5+';
    case 'ti':
      return 'ካልኣይ ዲግሪ ብትምህርቲ ሒሳብ (አአዩ) • ናይ 5+ ዓመታት ናይ ምምሃር ተሞክሮ';
    case 'so':
      return 'Shahaadada Labaad ee Xisaabta (Jaamacadda Addis Ababa) • Waayo-aragnimo 5+ Sano';
    case 'ar':
      return 'ماجستير في الرياضيات (جامعة أديس أبابا) • خبرة تدريس لأكثر من 5 سنوات';
    case 'fr':
      return 'Master en Mathématiques (Université d\'Addis-Abeba) • 5+ ans d\'expérience';
    case 'es':
      return 'Maestría en Matemáticas (Universidad de Adís Abeba) • Más de 5 años de experiencia';
    case 'de':
      return 'M.Sc. Mathematik (Universität Addis Abeba) • Über 5 Jahre Unterrichtserfahrung';
    case 'zh':
      return '数学理学硕士 (亚的斯亚贝巴大学) • 5年以上高水平辅导经验';
    case 'sw':
      return 'Shahada ya Uzamili ya Hisabati (Chuo Kikuu cha Addis Ababa) • Uzoefu wa miaka 5+';
    default:
      return 'M.Sc. Mathematics (AAU) • 5+ Years High School & College Tutoring';
  }
}

// Localized Service Badges and Chips (for Image 2 issue fix)
export function getLocalizedProgramChips(programId: 'tech' | 'lang' | 'ethics', lang: SupportedLanguage | string = 'en'): { chips: string[]; badge: string; enrollBtn: string } {
  const isAm = lang === 'am';
  const isOm = lang === 'om';
  const isTi = lang === 'ti';
  const isAr = lang === 'ar';
  const isFr = lang === 'fr';
  const isEs = lang === 'es';
  const isDe = lang === 'de';
  const isZh = lang === 'zh';
  const isSw = lang === 'sw';

  if (programId === 'tech') {
    let chips = ['Python & Scratch', 'Web Dev', 'MS Office & AI Tools', 'Digital Safety'];
    let badge = 'Certified Mentors';
    let enrollBtn = 'Enroll in Program';

    if (isAm) {
      chips = ['ፓይተን እና ስክራች', 'ዌብ ዲቨሎፕመንት', 'ኤምኤስ ኦፊስ እና AI', 'ዲጂታል ደህንነት'];
      badge = 'ብቁ አሰልጣኞች';
      enrollBtn = 'በፕሮግራሙ ይመዝገቡ';
    } else if (isOm) {
      chips = ['Paayitenii fi Iskiraach', 'Ijaarsa Weebii', 'MS Office fi AI', 'Nageenya Diijitaalaa'];
      badge = 'Leenjistoota Eebbifaman';
      enrollBtn = 'Sagantaa Kanatti Galmaa\'aa';
    } else if (isTi) {
      chips = ['ፓይተንን ስክራችን', 'ዌብ ዲቨሎፕመንት', 'ኤምኤስ ኦፊስን AI', 'ዲጂታል ድሕንነት'];
      badge = 'ብቑዓት መምህራን';
      enrollBtn = 'ኣብዚ መደብ ተመዝገቡ';
    } else if (isAr) {
      chips = ['بايثون وسكراتش', 'تطوير المواقع', 'أوفيس وأدوات AI', 'الأمان الرقمي'];
      badge = 'مدربون معتمدون';
      enrollBtn = 'سجّل في البرنامج';
    } else if (isZh) {
      chips = ['Python与Scratch', '网页开发', 'Office办公与AI工具', '数字安全'];
      badge = '认证导师指导';
      enrollBtn = '立即报名';
    } else if (isFr) {
      chips = ['Python & Scratch', 'Dév Web', 'MS Office & Outils IA', 'Sécurité Numérique'];
      badge = 'Mentors Certifiés';
      enrollBtn = 'S\'inscrire au programme';
    } else if (isSw) {
      chips = ['Python & Scratch', 'Uundaji wa Tovuti', 'MS Office & AI', 'Usalama wa Kidijitali'];
      badge = 'Wakufunzi Walioidhinishwa';
      enrollBtn = 'Jiunge na Mpango';
    }

    return { chips, badge, enrollBtn };
  }

  if (programId === 'lang') {
    let chips = ['English & IELTS', 'Afaan Oromoo', 'Amharic & Tigrinya', 'French & Arabic'];
    let badge = 'Native & Bilingual';
    let enrollBtn = 'Enroll in Program';

    if (isAm) {
      chips = ['እንግሊዝኛ እና IELTS', 'አፋን ኦሮሞ', 'አማርኛ እና ትግርኛ', 'ፈረንሳይኛ እና አረብኛ'];
      badge = 'የአፍ መፍቻ እና የሁለት ቋንቋ';
      enrollBtn = 'በፕሮግራሙ ይመዝገቡ';
    } else if (isOm) {
      chips = ['Afaan Ingilizii fi IELTS', 'Afaan Oromoo', 'Amaaraa fi Tigrinyi', 'Firaansisii fi Arabaa'];
      badge = 'Dubbattoota Dhalootaa';
      enrollBtn = 'Sagantaa Kanatti Galmaa\'aa';
    } else if (isTi) {
      chips = ['እንግሊዝኛን IELTS', 'ኣፋን ኦሮሞ', 'ኣምሓርኛን ትግርኛን', 'ፈረንሳይኛን ዓረብኛን'];
      badge = 'ናይ ቋንቋ መበቆላውያን';
      enrollBtn = 'ኣብዚ መደብ ተመዝገቡ';
    } else if (isAr) {
      chips = ['الإنجليزية وIELTS', 'عفان أورومو', 'الأمهرية والتغرينية', 'الفرنسية والعربية'];
      badge = 'متحدثون أصليون وثنائيو اللغة';
      enrollBtn = 'سجّل في البرنامج';
    } else if (isZh) {
      chips = ['英语与IELTS雅思', '奥罗莫语', '阿姆哈拉语与提格雷语', '法语与阿拉伯语'];
      badge = '母语及双语专家';
      enrollBtn = '立即报名';
    } else if (isFr) {
      chips = ['Anglais & IELTS', 'Afaan Oromo', 'Amharique & Tigrigna', 'Français & Arabe'];
      badge = 'Locuteurs Natifs & Bilingues';
      enrollBtn = 'S\'inscrire au programme';
    } else if (isSw) {
      chips = ['Kiingereza & IELTS', 'Kioromo', 'Kiamhari & Kitigrinya', 'Kifaransa & Kiarabu'];
      badge = 'Wazungumzaji Asilia';
      enrollBtn = 'Jiunge na Mpango';
    }

    return { chips, badge, enrollBtn };
  }

  // ethics
  let chips = ['Academic Integrity', 'Emotional IQ (EQ)', 'Leadership', 'Discipline & Habits'];
  let badge = 'Life-Long Value';
  let enrollBtn = 'Enroll in Program';

  if (isAm) {
    chips = ['የትምህርት ታማኝነት', 'የስሜት ብስለት (EQ)', 'አመራርነት', 'ዲሲፕሊን እና ልማድ'];
    badge = 'ዘላቂ የህይወት እሴት';
    enrollBtn = 'በፕሮግራሙ ይመዝገቡ';
  } else if (isOm) {
    chips = ['Amanamummaa Barnootaa', 'Qalbii Miiraa (EQ)', 'Hoggansa', 'Naamusa fi Amala'];
    badge = 'Gatii Umrii Guutuu';
    enrollBtn = 'Sagantaa Kanatti Galmaa\'aa';
  } else if (isTi) {
    chips = ['ናይ ትምህርቲ ተኣማንነት', 'ስምዒታዊ ብስለት (EQ)', 'መሪሕነት', 'ስነ-ስርዓትን ልምድን'];
    badge = 'ዘላቒ ናይ ህይወት ክብርታት';
    enrollBtn = 'ኣብዚ መደብ ተመዝገቡ';
  } else if (isAr) {
    chips = ['الأمانة الأكاديمية', 'الذكاء العاطفي (EQ)', 'مهارات القيادة', 'الانضباط والعادات'];
    badge = 'قيمة دائمة للحياة';
    enrollBtn = 'سجّل في البرنامج';
  } else if (isZh) {
    chips = ['学术诚信', '情商培养 (EQ)', '领导力提升', '自律与良好习惯'];
    badge = '终身受益的核心价值';
    enrollBtn = '立即报名';
  } else if (isFr) {
    chips = ['Intégrité Académique', 'Quotient Émotionnel (QE)', 'Leadership', 'Discipline & Habitudes'];
    badge = 'Valeur à Vie';
    enrollBtn = 'S\'inscrire au programme';
  } else if (isSw) {
    chips = ['Uadilifu wa Masomo', 'Ukomavu wa Kihisia (EQ)', 'Uongozi', 'Nidhamu na Tabia'];
    badge = 'Thamani ya Kudumu';
    enrollBtn = 'Jiunge na Mpango';
  }

  return { chips, badge, enrollBtn };
}
